import type { Lesao } from '@/lib/utils/lesoes'
import { createClient } from './server'

/**
 * Lesões de um aluno, mais recentes primeiro. `indisponivel` quando a
 * migração 022 ainda não foi aplicada (a tabela não existe).
 */
export async function getLesoesDoAluno(
  alunoId: string
): Promise<{ lesoes: Lesao[]; indisponivel: boolean }> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('lesoes')
    .select('*')
    .eq('aluno_id', alunoId)
    .order('status', { ascending: true })
    .order('created_at', { ascending: false })

  return { lesoes: (data as Lesao[] | null) ?? [], indisponivel: Boolean(error) }
}

/**
 * Lesões ativas por aluno — o formulário de treino mostra as do aluno
 * escolhido. Sem a migração 022 devolve vazio.
 */
export async function getLesoesAtivasPorAluno(
  alunoIds?: string[]
): Promise<Record<string, Lesao[]>> {
  const supabase = await createClient()
  let consulta = supabase
    .from('lesoes')
    .select('*')
    .eq('status', 'ativa')
    .order('created_at', { ascending: false })
  if (alunoIds) consulta = consulta.in('aluno_id', alunoIds)

  const { data } = await consulta

  const porAluno: Record<string, Lesao[]> = {}
  for (const lesao of (data as Lesao[] | null) ?? []) {
    ;(porAluno[lesao.aluno_id] ??= []).push(lesao)
  }
  return porAluno
}

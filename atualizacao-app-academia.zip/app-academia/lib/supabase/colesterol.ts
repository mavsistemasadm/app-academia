import type { RegistroColesterol } from '@/lib/utils/colesterol'
import { createClient } from './server'

/**
 * Exames de perfil lipídico do aluno, do mais recente ao mais antigo.
 * `indisponivel` quando a migração 023 ainda não foi aplicada.
 */
export async function getColesterolDoAluno(
  alunoId: string,
  limite = 24
): Promise<{ registros: RegistroColesterol[]; indisponivel: boolean }> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('colesterol_registros')
    .select('*')
    .eq('aluno_id', alunoId)
    .order('data', { ascending: false })
    .order('created_at', { ascending: false })
    .limit(limite)

  return {
    registros: (data as RegistroColesterol[] | null) ?? [],
    indisponivel: Boolean(error),
  }
}

import type {
  Exercicio,
  Indicador,
  IndicadorTipo,
  Profile,
  TreinoExecucao,
} from '@/lib/types'
import { indicadorPrioritario } from '@/lib/utils/avatares'
import { diaSemanaAtual, ehHoje, hojeISO } from '@/lib/utils/datas'
import { duracaoDaExecucao, inicioDaExecucao } from '@/lib/utils/duracao'
import { ehTipoTreino, tiposDoTreino, type TipoTreino } from '@/lib/utils/tipos-treino'
import { createClient } from './server'

export interface ExercicioComProgresso {
  id: string
  nome: string
  /** Sempre ≥ 1: exercício sem série definida vale como série única. */
  series: number
  repeticoes: string | null
  carga: string | null
  descanso: string | null
  videoUrl: string | null
  observacoes: string | null
  ordem: number
  tipo: TipoTreino | null
  /** Números das séries já marcadas hoje (1-indexado). */
  seriesFeitas: number[]
}

export interface TreinoDoDia {
  id: string
  nome: string
  descricao: string | null
  diaSemana: string[]
  /** Do treino e dos exercícios (migração 021). */
  tipos: TipoTreino[]
  exercicios: ExercicioComProgresso[]
  /** `null` enquanto o aluno não iniciou o treino hoje. */
  execucaoId: string | null
  concluido: boolean
  esforcoPercebido: number | null
  /**
   * Quando o treino começou hoje (primeira série). Da coluna `iniciado_em`
   * ou, antes da migração 008, do horário da primeira série.
   */
  inicioEm: string | null
  /** Tempo total, só quando concluído. `null` se não houver como saber. */
  duracaoSegundos: number | null
  totalSeries: number
  seriesFeitas: number
}

export interface OutroTreino {
  id: string
  nome: string
  diaSemana: string[]
  totalExercicios: number
  tipos: TipoTreino[]
}

export interface TreinoAlunoData {
  treino: TreinoDoDia | null
  /** Os demais treinos ativos, para o aluno saber o que vem nos outros dias. */
  outros: OutroTreino[]
  hoje: string
  /**
   * Módulo 13: o indicador que a condição clínica do aluno exige antes de
   * começar. `null` quando não há exigência ou quando ele já mediu hoje.
   */
  medirAntes: IndicadorTipo | null
  /**
   * A medição de hoje, quando ela saiu vermelha. O portão volta direto na
   * tela de aviso: atualizar a página não pode pular a confirmação.
   */
  leituraVermelha: Indicador | null
  /** Da última avaliação física — o portão precisa dela para o IMC. */
  altura: number | null
}

interface TreinoRow {
  id: string
  nome: string
  descricao: string | null
  dia_semana: string[] | null
  tipo?: string | null
  exercicios: Exercicio[] | null
}

export async function getTreinoAluno(
  perfil: Profile
): Promise<TreinoAlunoData> {
  const supabase = await createClient()

  const alunoId = perfil.id
  const hoje = hojeISO()
  const diaSemana = diaSemanaAtual()
  const exigido = indicadorPrioritario(perfil.avatar_condicao)

  const [{ data: treinos }, { data: avaliacao }, { data: mediuHoje }] =
    await Promise.all([
      supabase
        .from('treinos')
        // `*` traz `tipo` quando a migração 021 existe, sem quebrar antes dela.
        .select('*, exercicios(*)')
        .eq('aluno_id', alunoId)
        .eq('ativo', true)
        .order('created_at', { ascending: false }),
      supabase
        .from('avaliacoes_fisicas')
        .select('altura')
        .eq('aluno_id', alunoId)
        .not('altura', 'is', null)
        .order('data', { ascending: false })
        .limit(1)
        .maybeSingle(),
      exigido
        ? supabase
            .from('indicadores')
            .select('*')
            .eq('aluno_id', alunoId)
            .eq('tipo', exigido)
            // Meia-noite da academia, não a de Greenwich.
            .gte('created_at', `${hoje}T00:00:00-03:00`)
            .order('created_at', { ascending: false })
            .limit(1)
        : Promise.resolve({ data: null }),
    ])

  const altura = (avaliacao?.altura as number | undefined) ?? null
  // Já mediu hoje e não deu vermelho: não faz sentido cobrar de novo a cada
  // vez que abre a tela. No vermelho o portão continua de pé.
  const ultimaHoje = (mediuHoje?.[0] as Indicador | undefined) ?? null
  const leituraVermelha = ultimaHoje?.status_semaforo === 'vermelho' ? ultimaHoje : null
  const medirAntes = exigido && (!ultimaHoje || leituraVermelha) ? exigido : null

  const lista = (treinos ?? []) as TreinoRow[]
  const doDia = lista.find((t) => ehHoje(t.dia_semana, diaSemana)) ?? null

  const outros: OutroTreino[] = lista
    .filter((t) => t.id !== doDia?.id)
    .map((t) => ({
      id: t.id,
      nome: t.nome,
      diaSemana: t.dia_semana ?? [],
      totalExercicios: t.exercicios?.length ?? 0,
      tipos: tiposDoTreino(t.tipo, (t.exercicios ?? []).map((e) => e.tipo)),
    }))

  if (!doDia) return { treino: null, outros, hoje, medirAntes: null, leituraVermelha: null, altura }

  // `*` traz iniciado_em/duracao_segundos quando a migração 008 existe, sem
  // quebrar antes dela.
  const { data: execucaoRaw } = await supabase
    .from('treino_execucoes')
    .select('*')
    .eq('treino_id', doDia.id)
    .eq('aluno_id', alunoId)
    .eq('data', hoje)
    .maybeSingle()
  const execucao = execucaoRaw as TreinoExecucao | null

  // Só busca as séries se o treino já foi iniciado hoje.
  const { data: series } = execucao
    ? await supabase
        .from('exercicio_execucoes')
        .select('exercicio_id, serie, created_at')
        .eq('execucao_id', execucao.id)
    : { data: null }

  const horariosDasSeries = (series ?? []).map((s) => s.created_at as string)

  const feitasPorExercicio = new Map<string, number[]>()
  for (const s of series ?? []) {
    const atuais = feitasPorExercicio.get(s.exercicio_id) ?? []
    atuais.push(s.serie)
    feitasPorExercicio.set(s.exercicio_id, atuais)
  }

  const exercicios: ExercicioComProgresso[] = (doDia.exercicios ?? [])
    .slice()
    .sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0))
    .map((e) => ({
      id: e.id,
      nome: e.nome,
      series: Math.max(1, e.series ?? 1),
      repeticoes: e.repeticoes ?? null,
      carga: e.carga ?? null,
      descanso: e.descanso ?? null,
      videoUrl: e.video_url ?? null,
      observacoes: e.observacoes ?? null,
      ordem: e.ordem ?? 0,
      tipo: ehTipoTreino(e.tipo) ? e.tipo : null,
      seriesFeitas: (feitasPorExercicio.get(e.id) ?? []).sort((a, b) => a - b),
    }))

  return {
    treino: {
      id: doDia.id,
      nome: doDia.nome,
      descricao: doDia.descricao,
      diaSemana: doDia.dia_semana ?? [],
      tipos: tiposDoTreino(doDia.tipo, exercicios.map((e) => e.tipo)),
      exercicios,
      execucaoId: execucao?.id ?? null,
      concluido: Boolean(execucao?.concluido),
      esforcoPercebido: execucao?.esforco_percebido ?? null,
      inicioEm: execucao
        ? inicioDaExecucao(execucao, horariosDasSeries)
        : null,
      duracaoSegundos: execucao?.concluido
        ? duracaoDaExecucao(execucao, horariosDasSeries)
        : null,
      totalSeries: exercicios.reduce((soma, e) => soma + e.series, 0),
      seriesFeitas: exercicios.reduce(
        (soma, e) => soma + e.seriesFeitas.length,
        0
      ),
    },
    outros,
    hoje,
    // Treino já iniciado não volta para o portão no meio da série.
    medirAntes: execucao ? null : medirAntes,
    leituraVermelha: execucao ? null : leituraVermelha,
    altura,
  }
}

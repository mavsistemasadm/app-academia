import type { Videoaula } from '@/lib/utils/videoaulas'
import { createClient } from './server'

/**
 * Videoaulas, mais novas primeiro. O aluno recebe só as ativas (pela RLS e
 * pelo filtro); o professor, todas. `indisponivel` sem a migração 024.
 */
export async function getVideoaulas(
  { incluirOcultas = false } = {}
): Promise<{ videoaulas: Videoaula[]; indisponivel: boolean }> {
  const supabase = await createClient()
  let consulta = supabase
    .from('videoaulas')
    .select('*')
    .order('created_at', { ascending: false })
  if (!incluirOcultas) consulta = consulta.eq('ativo', true)

  const { data, error } = await consulta
  return { videoaulas: (data as Videoaula[] | null) ?? [], indisponivel: Boolean(error) }
}

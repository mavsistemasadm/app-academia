/**
 * Composição corporal por dobras cutâneas — Jackson & Pollock, 7 dobras,
 * com o percentual de gordura pela fórmula de Siri. Client-safe (sem
 * Supabase): a tela de avaliação calcula ao vivo e grava o resultado.
 *
 * As colunas que guardam isso nascem na migração 020. Antes dela, a
 * avaliação sem dobras continua salvando como sempre.
 */

export type Sexo = 'masculino' | 'feminino'

export const DOBRAS = [
  { id: 'dobra_peitoral', rotulo: 'Peitoral' },
  { id: 'dobra_axilar_media', rotulo: 'Axilar média' },
  { id: 'dobra_triceps', rotulo: 'Tríceps' },
  { id: 'dobra_subescapular', rotulo: 'Subescapular' },
  { id: 'dobra_abdominal', rotulo: 'Abdominal' },
  { id: 'dobra_suprailiaca', rotulo: 'Supra-ilíaca' },
  { id: 'dobra_coxa', rotulo: 'Coxa' },
] as const

export type DobraId = (typeof DOBRAS)[number]['id']

/** Faixa de idade em que a equação generalizada foi validada. */
export const IDADE_VALIDADA = { min: 18, max: 61 } as const

export interface ComposicaoCorporal {
  somaDobras: number
  densidade: number
  percentualGordura: number
  /** Só quando há peso. */
  massaGorda: number | null
  massaMagra: number | null
}

/** Densidade corporal (g/cm³) pela equação de 7 dobras de Jackson & Pollock. */
export function densidadeJacksonPollock7(soma: number, idade: number, sexo: Sexo): number {
  if (sexo === 'masculino') {
    return 1.112 - 0.00043499 * soma + 0.00000055 * soma ** 2 - 0.00028826 * idade
  }
  return 1.097 - 0.00046971 * soma + 0.00000056 * soma ** 2 - 0.00012828 * idade
}

/** Percentual de gordura pela fórmula de Siri. */
export function gorduraSiri(densidade: number): number {
  return (4.95 / densidade - 4.5) * 100
}

export function calcularComposicao(
  dobras: Record<DobraId, number>,
  idade: number,
  sexo: Sexo,
  peso: number | null
): ComposicaoCorporal {
  const somaDobras = DOBRAS.reduce((total, { id }) => total + dobras[id], 0)
  const densidade = densidadeJacksonPollock7(somaDobras, idade, sexo)
  const percentualGordura = gorduraSiri(densidade)
  const massaGorda = peso ? (peso * percentualGordura) / 100 : null

  return {
    somaDobras,
    densidade,
    percentualGordura,
    massaGorda,
    massaMagra: peso && massaGorda != null ? peso - massaGorda : null,
  }
}

/**
 * Idade completa em `dataISO` (a data da avaliação), sem passar por `Date`:
 * as duas pontas são datas de calendário e o fuso não pode mexer nelas.
 */
export function idadeNaData(nascimentoISO: string, dataISO: string): number | null {
  const [an, mn, dn] = nascimentoISO.slice(0, 10).split('-').map(Number)
  const [aa, ma, da] = dataISO.slice(0, 10).split('-').map(Number)
  if (![an, mn, dn, aa, ma, da].every(Number.isFinite)) return null

  const fezAniversario = ma > mn || (ma === mn && da >= dn)
  const idade = aa - an - (fezAniversario ? 0 : 1)
  return idade >= 0 ? idade : null
}

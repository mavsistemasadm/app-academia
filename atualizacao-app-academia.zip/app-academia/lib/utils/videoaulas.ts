/**
 * Biblioteca de videoaulas (migração 024) — client-safe. Os tipos são os do
 * treino mais "bem-estar".
 */

import { NOME_TIPO_TREINO, TIPOS_TREINO } from './tipos-treino'

export const TIPOS_VIDEOAULA = [...TIPOS_TREINO, 'bem_estar'] as const
export type TipoVideoaula = (typeof TIPOS_VIDEOAULA)[number]

export const NOME_TIPO_VIDEOAULA: Record<TipoVideoaula, string> = {
  ...NOME_TIPO_TREINO,
  bem_estar: 'Bem-estar',
}

export function ehTipoVideoaula(valor: unknown): valor is TipoVideoaula {
  return typeof valor === 'string' && (TIPOS_VIDEOAULA as readonly string[]).includes(valor)
}

export interface Videoaula {
  id: string
  professor_id: string | null
  titulo: string
  url: string
  descricao: string | null
  duracao_minutos: number | null
  tipo: TipoVideoaula
  ativo: boolean
  created_at: string
}

/** "8 min", "1 h 15 min". */
export function formatarMinutos(minutos: number | null): string | null {
  if (!minutos) return null
  if (minutos < 60) return `${minutos} min`
  const horas = Math.floor(minutos / 60)
  const resto = minutos % 60
  return resto ? `${horas} h ${resto} min` : `${horas} h`
}

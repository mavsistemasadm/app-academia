/**
 * Tipos de treino (migração 021) — client-safe. Valem para o treino inteiro e
 * para cada exercício; a biblioteca de videoaulas usa os mesmos, mais
 * "bem-estar".
 */

export const TIPOS_TREINO = ['mobilidade', 'forca', 'cardio', 'isometria'] as const

export type TipoTreino = (typeof TIPOS_TREINO)[number]

export const NOME_TIPO_TREINO: Record<TipoTreino, string> = {
  mobilidade: 'Mobilidade',
  forca: 'Força',
  cardio: 'Cardio',
  isometria: 'Isometria',
}

export function ehTipoTreino(valor: unknown): valor is TipoTreino {
  return typeof valor === 'string' && (TIPOS_TREINO as readonly string[]).includes(valor)
}

/**
 * Os tipos presentes num treino: o do próprio treino e os dos exercícios, sem
 * repetir e na ordem de `TIPOS_TREINO`. É o que o filtro compara.
 */
export function tiposDoTreino(
  tipoTreino: string | null | undefined,
  tiposExercicios: (string | null | undefined)[]
): TipoTreino[] {
  const presentes = new Set([tipoTreino, ...tiposExercicios].filter(ehTipoTreino))
  return TIPOS_TREINO.filter((t) => presentes.has(t))
}

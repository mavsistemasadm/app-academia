/**
 * Lesões e dores avisadas pelo aluno (migração 022) — client-safe.
 */

/** Atalhos de local; "Outro" abre o campo livre. */
export const LOCAIS_LESAO = [
  'Pescoço',
  'Ombro',
  'Cotovelo',
  'Punho ou mão',
  'Costas',
  'Lombar',
  'Quadril',
  'Coxa',
  'Joelho',
  'Panturrilha',
  'Tornozelo ou pé',
] as const

export const LADOS_LESAO = ['esquerdo', 'direito', 'ambos'] as const
export type LadoLesao = (typeof LADOS_LESAO)[number]

export const NOME_LADO: Record<LadoLesao, string> = {
  esquerdo: 'Esquerdo',
  direito: 'Direito',
  ambos: 'Os dois',
}

export interface Lesao {
  id: string
  aluno_id: string
  local: string
  lado: LadoLesao | null
  intensidade: number
  descricao: string | null
  /** `YYYY-MM-DD` — quando começou, segundo o aluno. */
  data: string
  status: 'ativa' | 'resolvida'
  resolvida_em: string | null
  resolvida_por: string | null
  created_at: string
}

/** "Joelho direito", "Lombar", "Ombro (os dois lados)". */
export function ondeDoi(lesao: Pick<Lesao, 'local' | 'lado'>): string {
  const local = lesao.local.trim()
  if (lesao.lado === 'ambos') return `${local} (os dois lados)`
  if (lesao.lado) return `${local} ${lesao.lado}`
  return local
}

export type FaixaIntensidade = 'leve' | 'moderada' | 'forte'

/** 0–3 leve, 4–6 moderada, 7–10 forte — a régua comum de dor de 0 a 10. */
export function faixaIntensidade(intensidade: number): FaixaIntensidade {
  if (intensidade >= 7) return 'forte'
  if (intensidade >= 4) return 'moderada'
  return 'leve'
}

export const ESTILO_INTENSIDADE: Record<FaixaIntensidade, { chip: string; rotulo: string }> = {
  leve: { chip: 'bg-saude-verde-light text-[#15803d]', rotulo: 'Leve' },
  moderada: { chip: 'bg-saude-amarelo-light text-[#b45309]', rotulo: 'Moderada' },
  forte: { chip: 'bg-saude-vermelho-light text-[#b91c1c]', rotulo: 'Forte' },
}

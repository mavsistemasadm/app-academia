import {
  Activity,
  Bandage,
  CalendarClock,
  CalendarDays,
  Clapperboard,
  ClipboardList,
  Droplets,
  Dumbbell,
  FileHeart,
  Heart,
  HeartHandshake,
  Home,
  LayoutDashboard,
  LineChart,
  MessageSquare,
  Pill,
  Sparkles,
  Flame,
  Trophy,
  User,
  UserCog,
  Users,
  type LucideIcon,
} from 'lucide-react'

export interface ItemNav {
  href: string
  label: string
  icone: LucideIcon
}

/**
 * Barra inferior do celular: as 4 telas do dia a dia. A quinta posição é o
 * botão "Mais", que abre a folha com todo o resto (ver BottomNav).
 */
export const NAV_MOBILE: ItemNav[] = [
  { href: '/home', label: 'Início', icone: Home },
  { href: '/treino', label: 'Treino', icone: Dumbbell },
  { href: '/indicadores', label: 'Saúde', icone: Activity },
  { href: '/aulas', label: 'Aulas', icone: CalendarClock },
]

const TITULOS: Record<string, string> = {
  '/home': 'Início',
  '/treino': 'Treino',
  '/indicadores': 'Indicadores',
  '/medicamentos': 'Medicamentos',
  '/evolucao': 'Evolução',
  '/exames': 'Exames',
  '/lesoes': 'Lesões e dores',
  '/humor': 'Meu humor',
  '/hidratacao': 'Hidratação',
  '/bem-estar': 'Bem-estar',
  '/videoaulas': 'Videoaulas',
  '/videoaulas-professor': 'Videoaulas',
  '/aulas': 'Aulas',
  '/conquistas': 'Conquistas',
  '/desafios': 'Desafios',
  '/agenda': 'Agenda',
  '/chat': 'Conversas',
  '/anamnese': 'Anamnese',
  '/perfil': 'Perfil',
  '/familiares': 'Dar acesso à família',
  '/acompanhar': 'Acompanhar um familiar',
  '/relatorio': 'Relatório',
}

/** Título curto da tela para a barra de topo do celular. */
export function tituloDaRota(pathname: string): string {
  return TITULOS[`/${pathname.split('/')[1] ?? ''}`] ?? 'Atitude Vital'
}

/** Sidebar do desktop — agrupada em seções. */
export const NAV_DESKTOP: { secao: string; itens: ItemNav[] }[] = [
  {
    secao: 'Principal',
    itens: [
      { href: '/home', label: 'Início', icone: Home },
      { href: '/treino', label: 'Meu treino', icone: Dumbbell },
      { href: '/indicadores', label: 'Indicadores', icone: Activity },
      { href: '/medicamentos', label: 'Medicamentos', icone: Pill },
      { href: '/aulas', label: 'Aulas', icone: CalendarClock },
    ],
  },
  {
    secao: 'Saúde',
    itens: [
      { href: '/evolucao', label: 'Evolução', icone: LineChart },
      { href: '/exames', label: 'Exames', icone: FileHeart },
      { href: '/lesoes', label: 'Lesões e dores', icone: Bandage },
      { href: '/humor', label: 'Meu humor', icone: Heart },
      { href: '/hidratacao', label: 'Hidratação', icone: Droplets },
      { href: '/bem-estar', label: 'Bem-estar', icone: Sparkles },
      { href: '/videoaulas', label: 'Videoaulas', icone: Clapperboard },
      { href: '/conquistas', label: 'Conquistas', icone: Trophy },
      { href: '/desafios', label: 'Desafios', icone: Flame },
    ],
  },
  {
    secao: 'Centro',
    itens: [
      { href: '/agenda', label: 'Agenda', icone: CalendarDays },
      { href: '/chat', label: 'Chat', icone: MessageSquare },
      { href: '/anamnese', label: 'Anamnese', icone: ClipboardList },
    ],
  },
  {
    secao: 'Conta',
    itens: [
      { href: '/perfil', label: 'Perfil', icone: User },
      { href: '/familiares', label: 'Dar acesso à família', icone: Users },
      { href: '/acompanhar', label: 'Acompanhar um familiar', icone: HeartHandshake },
    ],
  },
]

/** Abas do painel do professor. */
export const NAV_PROFESSOR: ItemNav[] = [
  { href: '/dashboard', label: 'Painel', icone: LayoutDashboard },
  { href: '/alunos', label: 'Alunos', icone: Users },
  { href: '/aulas-professor', label: 'Aulas', icone: CalendarClock },
  { href: '/treinos', label: 'Treinos', icone: Dumbbell },
  { href: '/agenda-professor', label: 'Agenda', icone: CalendarDays },
  { href: '/desafios-professor', label: 'Desafios', icone: Trophy },
  { href: '/presenca', label: 'Presença', icone: Activity },
  { href: '/videoaulas-professor', label: 'Videoaulas', icone: Clapperboard },
]

/**
 * Barra de baixo do professor: as 4 do dia a dia. O resto abre no "Mais",
 * como na do aluno.
 */
export const NAV_PROFESSOR_MOBILE: ItemNav[] = NAV_PROFESSOR.slice(0, 4)

/** Aba que só o admin vê (professor com eh_admin, migração 017). */
export const NAV_EQUIPE: ItemNav = { href: '/equipe', label: 'Equipe', icone: UserCog }

/** Abas do painel de quem está logado: o admin ganha a Equipe no fim. */
export function navDoProfessor(ehAdmin: boolean): ItemNav[] {
  return ehAdmin ? [...NAV_PROFESSOR, NAV_EQUIPE] : NAV_PROFESSOR
}

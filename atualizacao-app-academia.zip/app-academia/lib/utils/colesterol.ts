/**
 * Perfil lipídico (migração 023) — client-safe.
 *
 * Faixas do semáforo pelas referências da Sociedade Brasileira de Cardiologia
 * para adultos (Atualização da Diretriz de Dislipidemias, 2017, com os cortes
 * de "alto" da V Diretriz, 2013):
 *
 * | Medida            | Verde   | Amarelo  | Vermelho |
 * |-------------------|---------|----------|----------|
 * | Colesterol total  | < 190   | 190–239  | ≥ 240    |
 * | LDL               | < 130   | 130–159  | ≥ 160    |
 * | HDL               | ≥ 40    | < 40     | —        |
 * | Triglic. (jejum)  | < 150   | 150–499  | ≥ 500    |
 * | Triglic. (s/ jejum)| < 175  | 175–499  | ≥ 500    |
 *
 * A meta de LDL é individual (quanto maior o risco cardiovascular, menor a
 * meta) — quem define é o médico. Por isso a tela sempre avisa isso.
 */

import type { SemaforoStatus } from '@/lib/types'

export const MEDIDAS_LIPIDICAS = ['colesterol_total', 'ldl', 'hdl', 'triglicerides'] as const
export type MedidaLipidica = (typeof MEDIDAS_LIPIDICAS)[number]

export interface RegistroColesterol {
  id: string
  aluno_id: string
  /** `YYYY-MM-DD` da coleta. */
  data: string
  colesterol_total: number | null
  hdl: number | null
  ldl: number | null
  triglicerides: number | null
  jejum: boolean
  observacao: string | null
  created_at: string
}

interface ConfigMedida {
  label: string
  /** Rótulo do campo no formulário. */
  campo: string
  curto: string
  /** Faixa desejável desenhada no gráfico. */
  ideal: { min?: number; max?: number }
  /** Subir é bom só no HDL. */
  maiorMelhor: boolean
  referencia: { verde: string; amarelo: string; vermelho: string | null }
  exemplo: string
}

export const CONFIG_LIPIDICA: Record<MedidaLipidica, ConfigMedida> = {
  colesterol_total: {
    label: 'Colesterol total',
    campo: 'Colesterol total',
    curto: 'Total',
    ideal: { max: 190 },
    maiorMelhor: false,
    referencia: { verde: '< 190', amarelo: '190 a 239', vermelho: '≥ 240' },
    exemplo: '185',
  },
  ldl: {
    label: 'LDL (colesterol "ruim")',
    campo: 'LDL',
    curto: 'LDL',
    ideal: { max: 130 },
    maiorMelhor: false,
    referencia: { verde: '< 130', amarelo: '130 a 159', vermelho: '≥ 160' },
    exemplo: '110',
  },
  hdl: {
    label: 'HDL (colesterol "bom")',
    campo: 'HDL',
    curto: 'HDL',
    ideal: { min: 40 },
    maiorMelhor: true,
    referencia: { verde: '≥ 40', amarelo: '< 40', vermelho: null },
    exemplo: '52',
  },
  triglicerides: {
    label: 'Triglicerídeos',
    campo: 'Triglicerídeos',
    curto: 'Triglic.',
    ideal: { max: 150 },
    maiorMelhor: false,
    referencia: { verde: '< 150 (jejum) · < 175 (sem jejum)', amarelo: 'até 499', vermelho: '≥ 500' },
    exemplo: '140',
  },
}

/** Limites aceitos no formulário — os mesmos `check` da migração 023. */
export const LIMITES_LIPIDICOS: Record<MedidaLipidica, [number, number]> = {
  colesterol_total: [50, 600],
  hdl: [5, 200],
  ldl: [10, 500],
  triglicerides: [20, 5000],
}

export function statusLipidico(
  medida: MedidaLipidica,
  valor: number,
  jejum = true
): SemaforoStatus {
  switch (medida) {
    case 'colesterol_total':
      return valor >= 240 ? 'vermelho' : valor >= 190 ? 'amarelo' : 'verde'
    case 'ldl':
      return valor >= 160 ? 'vermelho' : valor >= 130 ? 'amarelo' : 'verde'
    case 'hdl':
      return valor >= 40 ? 'verde' : 'amarelo'
    case 'triglicerides':
      if (valor >= 500) return 'vermelho'
      return valor >= (jejum ? 150 : 175) ? 'amarelo' : 'verde'
  }
}

export function numeroLipidico(valor: number): string {
  return valor.toLocaleString('pt-BR', { maximumFractionDigits: 1 })
}

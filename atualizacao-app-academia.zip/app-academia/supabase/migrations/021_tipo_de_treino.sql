-- ============================================================
-- 021 · Tipo de treino (mobilidade, força, cardio, isometria)
--
-- APLICAR NO SQL EDITOR DO SUPABASE (DDL não roda pela service role).
--
-- Só acrescenta uma coluna opcional em `treinos` e outra em `exercicios`.
-- Treinos e exercícios que já existem ficam sem tipo e seguem iguais; as
-- policies da 019 continuam valendo.
--
-- Pode rodar mais de uma vez sem estragar nada.
-- ============================================================

alter table public.treinos   add column if not exists tipo text;
alter table public.exercicios add column if not exists tipo text;

alter table public.treinos drop constraint if exists treino_tipo_valido;
alter table public.treinos add constraint treino_tipo_valido
  check (tipo is null or tipo in ('mobilidade', 'forca', 'cardio', 'isometria'));

alter table public.exercicios drop constraint if exists exercicio_tipo_valido;
alter table public.exercicios add constraint exercicio_tipo_valido
  check (tipo is null or tipo in ('mobilidade', 'forca', 'cardio', 'isometria'));

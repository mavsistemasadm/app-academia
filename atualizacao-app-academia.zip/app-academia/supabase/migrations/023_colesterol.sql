-- ============================================================
-- 023 · Colesterol e triglicerídeos (perfil lipídico)
--
-- APLICAR NO SQL EDITOR DO SUPABASE (DDL não roda pela service role).
--
-- Tabela nova `colesterol_registros`: um registro por exame de sangue, com
-- colesterol total, HDL, LDL e triglicerídeos (qualquer combinação, ao menos
-- um). O semáforo é calculado no app (lib/utils/colesterol.ts) pelas faixas
-- da SBC; perfil lipídico não gera alerta em tempo real, porque não muda de
-- um dia para o outro.
--
-- Mesma regra dos indicadores (019): o aluno registra e lê os dele, não
-- edita depois; professor lê todos. Nada que já existe muda.
-- Pode rodar mais de uma vez sem estragar nada.
-- ============================================================

create table if not exists public.colesterol_registros (
  id uuid primary key default gen_random_uuid(),
  aluno_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  -- Data da coleta do exame.
  data date not null,
  colesterol_total numeric check (colesterol_total is null or colesterol_total between 50 and 600),
  hdl numeric check (hdl is null or hdl between 5 and 200),
  ldl numeric check (ldl is null or ldl between 10 and 500),
  triglicerides numeric check (triglicerides is null or triglicerides between 20 and 5000),
  -- Triglicerídeos têm referência diferente com e sem jejum.
  jejum boolean not null default true,
  observacao text check (observacao is null or char_length(observacao) <= 500),
  created_at timestamptz not null default now(),
  constraint colesterol_ao_menos_um check (
    colesterol_total is not null or hdl is not null
    or ldl is not null or triglicerides is not null
  )
);

create index if not exists colesterol_por_aluno
  on public.colesterol_registros (aluno_id, data desc);

alter table public.colesterol_registros enable row level security;

drop policy if exists colesterol_leitura on public.colesterol_registros;
create policy colesterol_leitura on public.colesterol_registros
  for select to authenticated
  using (auth.uid() = aluno_id or public.eh_professor());

drop policy if exists colesterol_aluno_registra on public.colesterol_registros;
create policy colesterol_aluno_registra on public.colesterol_registros
  for insert to authenticated
  with check (auth.uid() = aluno_id);

-- ============================================================
-- 024 · Biblioteca de videoaulas
--
-- APLICAR NO SQL EDITOR DO SUPABASE (DDL não roda pela service role).
--
-- Tabela nova `videoaulas`: o professor cadastra título, link (YouTube,
-- Vimeo ou arquivo), descrição, duração e tipo; o aluno assiste. A
-- biblioteca é da casa: qualquer professor cadastra, edita, oculta e apaga.
--
-- Nada que já existe muda. Pode rodar mais de uma vez sem estragar nada.
-- ============================================================

create table if not exists public.videoaulas (
  id uuid primary key default gen_random_uuid(),
  professor_id uuid default auth.uid() references public.profiles(id) on delete set null,
  titulo text not null check (char_length(btrim(titulo)) between 2 and 120),
  url text not null check (char_length(url) <= 500),
  descricao text check (descricao is null or char_length(descricao) <= 1000),
  duracao_minutos integer check (duracao_minutos is null or duracao_minutos between 1 and 300),
  tipo text not null check (tipo in ('mobilidade', 'forca', 'cardio', 'isometria', 'bem_estar')),
  -- Ocultar tira da tela do aluno sem perder o cadastro.
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists videoaulas_por_tipo on public.videoaulas (tipo, created_at desc);

alter table public.videoaulas enable row level security;

-- Quem está logado vê as ativas; professor vê todas.
drop policy if exists videoaulas_leitura on public.videoaulas;
create policy videoaulas_leitura on public.videoaulas
  for select to authenticated
  using (ativo or public.eh_professor());

drop policy if exists videoaulas_professor_gerencia on public.videoaulas;
create policy videoaulas_professor_gerencia on public.videoaulas
  for all to authenticated
  using (public.eh_professor())
  with check (public.eh_professor());

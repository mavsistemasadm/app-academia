-- ============================================================
-- 020 · Composição corporal por dobras cutâneas (Jackson & Pollock 7)
--
-- APLICAR NO SQL EDITOR DO SUPABASE (DDL não roda pela service role).
--
-- Só acrescenta colunas novas, todas vazias, em avaliacoes_fisicas. Nenhuma
-- avaliação já lançada muda e as policies da 019 continuam valendo: o aluno
-- lê as dele e só professor lança, corrige ou apaga.
--
-- O % de gordura calculado vai para a coluna que já existe
-- (percentual_gordura), por isso a ficha e a Evolução já o mostram.
--
-- Pode rodar mais de uma vez sem estragar nada.
-- ============================================================

alter table public.avaliacoes_fisicas
  add column if not exists protocolo text,
  add column if not exists sexo text,
  add column if not exists idade integer,
  add column if not exists dobra_peitoral numeric,
  add column if not exists dobra_axilar_media numeric,
  add column if not exists dobra_triceps numeric,
  add column if not exists dobra_subescapular numeric,
  add column if not exists dobra_abdominal numeric,
  add column if not exists dobra_suprailiaca numeric,
  add column if not exists dobra_coxa numeric,
  add column if not exists soma_dobras numeric,
  add column if not exists densidade_corporal numeric,
  add column if not exists massa_gorda numeric,
  add column if not exists massa_magra numeric;

alter table public.avaliacoes_fisicas
  drop constraint if exists avaliacao_sexo_valido;
alter table public.avaliacoes_fisicas
  add constraint avaliacao_sexo_valido
  check (sexo is null or sexo in ('masculino', 'feminino'));

alter table public.avaliacoes_fisicas
  drop constraint if exists avaliacao_protocolo_valido;
alter table public.avaliacoes_fisicas
  add constraint avaliacao_protocolo_valido
  check (protocolo is null or protocolo = 'jackson_pollock_7');

comment on column public.avaliacoes_fisicas.protocolo is
  'jackson_pollock_7 quando a avaliação tem as 7 dobras; vazio nas demais.';
comment on column public.avaliacoes_fisicas.densidade_corporal is
  'g/cm³ pela equação de Jackson & Pollock; % de gordura pela fórmula de Siri.';

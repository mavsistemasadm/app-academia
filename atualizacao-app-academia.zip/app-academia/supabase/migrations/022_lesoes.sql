-- ============================================================
-- 022 · Lesões e dores informadas pelo aluno
--
-- APLICAR NO SQL EDITOR DO SUPABASE (DDL não roda pela service role).
--
-- Tabela nova `lesoes`. O aluno avisa (local, lado, intensidade 0 a 10,
-- descrição, data); o gatilho cria um alerta em `alertas_professor` para o
-- professor responsável — e, por isso, chega no painel em tempo real, no
-- sininho e no push pelos gatilhos que já existem (018/019). O professor
-- marca como resolvida.
--
-- Nada que já existe muda. Pode rodar mais de uma vez sem estragar nada.
-- ============================================================

create table if not exists public.lesoes (
  id uuid primary key default gen_random_uuid(),
  aluno_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  local text not null check (char_length(btrim(local)) between 2 and 60),
  lado text check (lado is null or lado in ('esquerdo', 'direito', 'ambos')),
  intensidade integer not null check (intensidade between 0 and 10),
  descricao text check (descricao is null or char_length(descricao) <= 1000),
  data date not null,
  status text not null default 'ativa' check (status in ('ativa', 'resolvida')),
  resolvida_em timestamptz,
  resolvida_por uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists lesoes_por_aluno on public.lesoes (aluno_id, created_at desc);
create index if not exists lesoes_ativas on public.lesoes (aluno_id) where status = 'ativa';

alter table public.lesoes enable row level security;

-- O aluno lê as dele; todo professor lê (a ficha é da casa inteira).
drop policy if exists lesoes_leitura on public.lesoes;
create policy lesoes_leitura on public.lesoes
  for select to authenticated
  using (auth.uid() = aluno_id or public.eh_professor());

-- O aluno só avisa em nome próprio e sempre como "ativa".
drop policy if exists lesoes_aluno_avisa on public.lesoes;
create policy lesoes_aluno_avisa on public.lesoes
  for insert to authenticated
  with check (
    auth.uid() = aluno_id
    and status = 'ativa'
    and resolvida_em is null
    and resolvida_por is null
  );

-- Só professor resolve (ou reabre). O aluno não edita nem apaga o aviso.
drop policy if exists lesoes_professor_atualiza on public.lesoes;
create policy lesoes_professor_atualiza on public.lesoes
  for update to authenticated
  using (public.eh_professor())
  with check (public.eh_professor());

-- Aviso novo vira alerta para o professor responsável.
create or replace function public.alertar_lesao_nova()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_professor_id uuid;
  v_onde text;
begin
  v_professor_id := public.professor_responsavel(new.aluno_id);
  if v_professor_id is null then
    return new;
  end if;

  v_onde := btrim(new.local) || case new.lado
    when 'esquerdo' then ' esquerdo'
    when 'direito' then ' direito'
    when 'ambos' then ' (os dois lados)'
    else ''
  end;

  insert into alertas_professor (professor_id, aluno_id, tipo, mensagem, dados)
  values (
    v_professor_id, new.aluno_id, 'lesao',
    'Avisou lesão ou dor: ' || v_onde || ', intensidade ' || new.intensidade || ' de 10.',
    jsonb_build_object(
      'lesao_id', new.id,
      'local', new.local,
      'lado', new.lado,
      'intensidade', new.intensidade,
      'data', new.data
    )
  );

  return new;
exception when others then
  -- O aviso do aluno nunca se perde por causa do alerta.
  raise warning 'alertar_lesao_nova: %', sqlerrm;
  return new;
end;
$$;

revoke all on function public.alertar_lesao_nova() from public, anon, authenticated;

drop trigger if exists trigger_lesao_alerta on public.lesoes;
create trigger trigger_lesao_alerta
  after insert on public.lesoes
  for each row execute function public.alertar_lesao_nova();

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import { hojeISO } from "@/lib/utils/datas";
import {
  ESTILO_INTENSIDADE,
  LADOS_LESAO,
  LOCAIS_LESAO,
  NOME_LADO,
  faixaIntensidade,
  ondeDoi,
  type LadoLesao,
  type Lesao,
} from "@/lib/utils/lesoes";

const CARD = "flex flex-col gap-5 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90 md:p-6";
const TITULO_SECAO = "text-lg font-semibold tracking-[-0.02em] text-neutral-950 md:text-xl";
const ENUNCIADO = "text-sm leading-snug font-medium text-neutral-700";
const PILULA =
  "rounded-full text-sm font-medium transition-all duration-200 active:scale-[.98] disabled:opacity-60";
const PILULA_MARCADA = "bg-grafite text-white";
const PILULA_LIVRE =
  "bg-neutral-50 text-neutral-700 ring-1 ring-neutral-200 hover:bg-neutral-100";
const TEXTAREA =
  "w-full resize-none rounded-[14px] border border-input bg-card px-3.5 py-3 text-base transition-colors outline-none placeholder:text-neutral-400 hover:border-neutral-300 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-60";

const OUTRO = "Outro";

const dataBR = (iso: string) =>
  format(new Date(`${iso.slice(0, 10)}T12:00:00Z`), "d 'de' MMMM", { locale: ptBR });

interface AvisarLesaoProps {
  alunoId: string;
  lesoes: Lesao[];
  /** `YYYY-MM-DD` da academia, calculado no servidor. */
  hoje: string;
  /** A migração 022 ainda não foi aplicada. */
  indisponivel: boolean;
}

export function AvisarLesao({ alunoId, lesoes, hoje, indisponivel }: AvisarLesaoProps) {
  const router = useRouter();

  const [atalho, setAtalho] = useState<string | null>(null);
  const [outroLocal, setOutroLocal] = useState("");
  const [lado, setLado] = useState<LadoLesao | null>(null);
  const [intensidade, setIntensidade] = useState<number | null>(null);
  const [data, setData] = useState(hoje);
  const [descricao, setDescricao] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);
  const [enviado, setEnviado] = useState(false);

  const local = atalho === OUTRO ? outroLocal.trim() : (atalho ?? "");

  if (indisponivel) {
    return (
      <div className="flex items-start gap-3.5 rounded-2xl bg-card px-5 py-4 ring-1 ring-neutral-200/90">
        <AlertCircle className="mt-0.5 size-5 shrink-0 text-neutral-400" strokeWidth={1.8} aria-hidden />
        <p className="text-sm leading-relaxed text-neutral-500">
          O aviso de lesões ainda está sendo ativado pelo centro. Enquanto isso, conte
          ao professor pelo chat.
        </p>
      </div>
    );
  }

  async function avisar(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro(null);

    if (local.length < 2) return setErro("Diga onde está a dor ou a lesão.");
    if (local.length > 60) return setErro("Descreva o local em poucas palavras.");
    if (intensidade === null) return setErro("Marque a intensidade, de 0 a 10.");
    if (!data || data > hoje) return setErro("Informe quando começou (hoje ou antes).");

    setSalvando(true);
    const { error } = await createClient().from("lesoes").insert({
      aluno_id: alunoId,
      local,
      lado,
      intensidade,
      descricao: descricao.trim() || null,
      data,
    });
    setSalvando(false);

    if (error) {
      return setErro("Não conseguimos enviar o aviso. Confira a conexão e tente de novo.");
    }

    setAtalho(null);
    setOutroLocal("");
    setLado(null);
    setIntensidade(null);
    setData(hoje);
    setDescricao("");
    setEnviado(true);
    router.refresh();
  }

  const faixa = intensidade !== null ? faixaIntensidade(intensidade) : null;

  return (
    <>
      <form onSubmit={avisar} className={CARD} noValidate>
        <div>
          <h2 className={TITULO_SECAO}>Avisar lesão ou dor</h2>
          <p className="mt-0.5 text-sm text-neutral-500">
            O professor recebe na hora e ajusta o seu treino.
          </p>
        </div>

        <fieldset className="flex flex-col gap-2.5" disabled={salvando}>
          <legend className={cn(ENUNCIADO, "mb-2.5")}>Onde?</legend>
          <div className="flex flex-wrap gap-1.5">
            {[...LOCAIS_LESAO, OUTRO].map((opcao) => (
              <button
                key={opcao}
                type="button"
                onClick={() => {
                  setAtalho(atalho === opcao ? null : opcao);
                  setEnviado(false);
                }}
                aria-pressed={atalho === opcao}
                className={cn(PILULA, "h-11 px-4", atalho === opcao ? PILULA_MARCADA : PILULA_LIVRE)}
              >
                {opcao}
              </button>
            ))}
          </div>
          {atalho === OUTRO && (
            <Input
              value={outroLocal}
              onChange={(e) => setOutroLocal(e.target.value)}
              placeholder="Ex.: dedo do pé, mandíbula"
              aria-label="Outro local"
              maxLength={60}
              className="h-12 px-3.5 text-base"
            />
          )}
        </fieldset>

        <fieldset className="flex flex-col gap-2.5" disabled={salvando}>
          <legend className={cn(ENUNCIADO, "mb-2.5")}>
            Lado <span className="font-normal text-neutral-400">(se tiver)</span>
          </legend>
          <div className="flex gap-1.5">
            {LADOS_LESAO.map((opcao) => (
              <button
                key={opcao}
                type="button"
                onClick={() => setLado(lado === opcao ? null : opcao)}
                aria-pressed={lado === opcao}
                className={cn(PILULA, "h-11 flex-1 sm:w-28 sm:flex-none", lado === opcao ? PILULA_MARCADA : PILULA_LIVRE)}
              >
                {NOME_LADO[opcao]}
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset className="flex flex-col gap-2" disabled={salvando}>
          <legend className={cn(ENUNCIADO, "mb-2.5 flex w-full items-center justify-between gap-2")}>
            <span>Intensidade da dor</span>
            {faixa && (
              <span className={cn("rounded-full px-2.5 py-0.5 text-[11px] font-semibold", ESTILO_INTENSIDADE[faixa].chip)}>
                {ESTILO_INTENSIDADE[faixa].rotulo}
              </span>
            )}
          </legend>
          <div className="grid grid-cols-6 gap-1.5 sm:flex sm:flex-wrap">
            {Array.from({ length: 11 }, (_, nota) => (
              <button
                key={nota}
                type="button"
                onClick={() => setIntensidade(nota)}
                aria-pressed={intensidade === nota}
                aria-label={`${nota} de 10`}
                className={cn(PILULA, "numero h-11 sm:w-11", intensidade === nota ? PILULA_MARCADA : PILULA_LIVRE)}
              >
                {nota}
              </button>
            ))}
          </div>
          <div className="rotulo flex justify-between text-neutral-400 sm:max-w-[564px]">
            <span>0 · sem dor</span>
            <span>10 · insuportável</span>
          </div>
        </fieldset>

        <div className="flex flex-col gap-2 sm:w-52">
          <Label htmlFor="lesao-data" className="text-neutral-700">
            Quando começou
          </Label>
          <Input
            id="lesao-data"
            type="date"
            value={data}
            max={hoje}
            onChange={(e) => setData(e.target.value)}
            disabled={salvando}
            className="h-12 px-3.5 text-base"
          />
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="lesao-descricao" className="text-neutral-700">
            Conte mais <span className="font-normal text-neutral-400">(opcional)</span>
          </Label>
          <textarea
            id="lesao-descricao"
            rows={3}
            maxLength={1000}
            value={descricao}
            onChange={(e) => setDescricao(e.target.value)}
            placeholder="Como aconteceu, o que piora, se já foi ao médico."
            disabled={salvando}
            className={TEXTAREA}
          />
        </div>

        {erro && (
          <p role="alert" className="flex items-start gap-2 text-sm text-saude-vermelho">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            {erro}
          </p>
        )}
        {enviado && !erro && (
          <p role="status" className="flex items-start gap-2 text-sm font-medium text-saude-verde">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0" aria-hidden />
            Pronto, o professor foi avisado.
          </p>
        )}

        <Button
          type="submit"
          disabled={salvando}
          className="h-12 w-full rounded-full text-base font-semibold sm:w-auto sm:self-start sm:px-8"
        >
          {salvando ? (
            <>
              <Loader2 className="size-5 animate-spin" aria-hidden />
              Enviando...
            </>
          ) : (
            "Avisar o professor"
          )}
        </Button>
      </form>

      {lesoes.length > 0 && (
        <section className="flex flex-col gap-3.5">
          <h2 className={TITULO_SECAO}>Meus avisos</h2>
          <ul className="flex flex-col divide-y divide-neutral-200/80 overflow-hidden rounded-2xl bg-card ring-1 ring-neutral-200/90">
            {lesoes.map((lesao) => {
              const estilo = ESTILO_INTENSIDADE[faixaIntensidade(lesao.intensidade)];
              return (
                <li key={lesao.id} className="flex flex-col gap-1.5 px-5 py-4">
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-[15px] font-semibold text-neutral-950">{ondeDoi(lesao)}</p>
                    <span
                      className={cn(
                        "shrink-0 rounded-full px-2.5 py-0.5 text-[11px] font-semibold",
                        lesao.status === "ativa" ? estilo.chip : "bg-neutral-100 text-neutral-500"
                      )}
                    >
                      {lesao.status === "ativa"
                        ? `${lesao.intensidade}/10 · ${estilo.rotulo}`
                        : "Resolvida"}
                    </span>
                  </div>
                  <p className="rotulo text-neutral-400">
                    Desde {dataBR(lesao.data)}
                    {lesao.status === "resolvida" && lesao.resolvida_em
                      ? // Instante em UTC: a data que vale é a da academia.
                        ` · resolvida em ${dataBR(hojeISO(new Date(lesao.resolvida_em)))}`
                      : ""}
                  </p>
                  {lesao.descricao && (
                    <p className="text-sm leading-relaxed text-neutral-600">{lesao.descricao}</p>
                  )}
                </li>
              );
            })}
          </ul>
        </section>
      )}
    </>
  );
}

"use client";

import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Area,
  CartesianGrid,
  ComposedChart,
  ReferenceArea,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { CHIP_SEMAFORO } from "@/components/aluno/CardIndicador";
import { cn } from "@/lib/utils";
import {
  CONFIG_LIPIDICA,
  MEDIDAS_LIPIDICAS,
  numeroLipidico,
  statusLipidico,
  type MedidaLipidica,
  type RegistroColesterol,
} from "@/lib/utils/colesterol";
import { SEMAFORO_CONFIG } from "@/lib/utils/semaforo";

/*
  Um gráfico pequeno por medida, cada um com o seu eixo (nunca dois eixos
  no mesmo gráfico). Mesmo desenho do GraficoIndicador: uma cor só, área
  suave, faixa desejável em verde ao fundo, último ponto em destaque.
  SVG não resolve `var()` em atributo de apresentação: os tokens vão escritos.
*/
const CIANO = "#0A8FA3";
const CINZA_EIXO = "#93A0A3";
const CINZA_GRADE = "#DFE6E7";
const VERDE_FAIXA = "#16A34A";

interface Ponto {
  data: string;
  valor: number;
  jejum: boolean;
}

const dataCurta = (iso: string) =>
  format(new Date(`${iso}T12:00:00Z`), "MMM/yy", { locale: ptBR });
const dataLonga = (iso: string) =>
  format(new Date(`${iso}T12:00:00Z`), "d 'de' MMM yyyy", { locale: ptBR });

/** Série de uma medida: um ponto por exame, do mais antigo ao mais novo. */
function serieDe(medida: MedidaLipidica, registros: RegistroColesterol[]): Ponto[] {
  return registros
    .filter((r) => r[medida] != null)
    .map((r) => ({ data: r.data, valor: Number(r[medida]), jejum: r.jejum }))
    .sort((a, b) => a.data.localeCompare(b.data));
}

interface GraficoColesterolProps {
  /** Em qualquer ordem. */
  registros: RegistroColesterol[];
  /** Na folha impressa: sem hover nem tabela recolhível. */
  impressao?: boolean;
}

export function GraficoColesterol({ registros, impressao = false }: GraficoColesterolProps) {
  const medidas = MEDIDAS_LIPIDICAS.filter((m) => registros.some((r) => r[m] != null));

  return (
    <div className={cn("grid gap-3 md:gap-4", impressao ? "grid-cols-2" : "sm:grid-cols-2")}>
      {medidas.map((medida) => (
        <CartaoMedida
          key={medida}
          medida={medida}
          pontos={serieDe(medida, registros)}
          impressao={impressao}
        />
      ))}
    </div>
  );
}

function CartaoMedida({
  medida,
  pontos,
  impressao,
}: {
  medida: MedidaLipidica;
  pontos: Ponto[];
  impressao: boolean;
}) {
  const config = CONFIG_LIPIDICA[medida];
  const ultimo = pontos[pontos.length - 1];
  const anterior = pontos[pontos.length - 2];
  const status = statusLipidico(medida, ultimo.valor, ultimo.jejum);
  const diferenca = anterior ? ultimo.valor - anterior.valor : null;
  const melhorou =
    diferenca !== null && (config.maiorMelhor ? diferenca > 0 : diferenca < 0);

  const valores = pontos.map((p) => p.valor);
  const limites = [config.ideal.min, config.ideal.max].filter((v): v is number => v != null);
  const minimo = Math.min(...valores, ...limites);
  const maximo = Math.max(...valores, ...limites);
  const folga = Math.max(5, (maximo - minimo) * 0.2);
  const piso = Math.max(0, Math.floor(minimo - folga));
  const teto = Math.ceil(maximo + folga);
  const indiceFinal = pontos.length - 1;

  return (
    <div className="flex break-inside-avoid flex-col gap-3 rounded-2xl bg-card p-4 ring-1 ring-neutral-200/90 md:p-5">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[13px] font-medium text-neutral-500">{config.label}</p>
          <p className="numero mt-1 text-[26px] leading-none font-semibold text-neutral-950">
            {numeroLipidico(ultimo.valor)}
            <span className="ml-1 font-sans text-xs font-medium tracking-normal text-neutral-400">
              mg/dL
            </span>
          </p>
        </div>
        <span
          className={cn(
            "shrink-0 rounded-full px-2.5 py-0.5 text-[11px] font-semibold",
            CHIP_SEMAFORO[status]
          )}
        >
          {SEMAFORO_CONFIG[status].label}
        </span>
      </div>

      <p className="text-[13px] text-neutral-500">
        {diferenca === null ? (
          `Um exame, de ${dataLonga(ultimo.data)}. O gráfico aparece a partir do segundo.`
        ) : Math.abs(diferenca) < 0.5 ? (
          "Igual ao exame anterior."
        ) : (
          <span className={cn("font-medium", melhorou ? "text-saude-verde" : "text-neutral-500")}>
            {diferenca > 0 ? "+" : "−"}
            {numeroLipidico(Math.abs(diferenca))} mg/dL desde o exame anterior
          </span>
        )}
      </p>

      {pontos.length > 1 && (
        <div className="h-36 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={pontos} margin={{ top: 8, right: 10, bottom: 0, left: -18 }}>
              <defs>
                <linearGradient id={`grad-${medida}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={CIANO} stopOpacity={0.16} />
                  <stop offset="100%" stopColor={CIANO} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke={CINZA_GRADE} strokeDasharray="2 4" />
              <ReferenceArea
                y1={config.ideal.min ?? piso}
                y2={config.ideal.max ?? teto}
                fill={VERDE_FAIXA}
                fillOpacity={0.07}
                stroke="none"
              />
              <XAxis
                dataKey="data"
                tickFormatter={dataCurta}
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 11, fill: CINZA_EIXO }}
                tickMargin={6}
                minTickGap={20}
              />
              <YAxis
                domain={[piso, teto]}
                tickLine={false}
                axisLine={false}
                tick={{ fontSize: 11, fill: CINZA_EIXO }}
                width={44}
                tickCount={4}
              />
              {!impressao && (
                <Tooltip
                  cursor={{ stroke: CINZA_GRADE, strokeWidth: 1 }}
                  content={<Dica />}
                />
              )}
              <Area
                type="monotone"
                dataKey="valor"
                name={config.curto}
                stroke={CIANO}
                strokeWidth={2}
                fill={`url(#grad-${medida})`}
                baseValue={piso}
                dot={({ cx, cy, index }: { cx?: number; cy?: number; index?: number }) =>
                  index === indiceFinal && cx != null && cy != null ? (
                    <g key={`p-${index}`}>
                      <circle cx={cx} cy={cy} r={8} fill={CIANO} fillOpacity={0.15} />
                      <circle cx={cx} cy={cy} r={4} fill={CIANO} stroke="#FFFFFF" strokeWidth={2} />
                    </g>
                  ) : (
                    <circle key={`p-${index}`} cx={cx} cy={cy} r={2.5} fill={CIANO} />
                  )
                }
                activeDot={{ r: 5, strokeWidth: 2, stroke: "#FFFFFF", fill: CIANO }}
                isAnimationActive={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}

      {!impressao && pontos.length > 1 && (
        <details>
          <summary className="w-fit cursor-pointer text-[13px] font-medium text-neutral-500 underline-offset-4 hover:text-neutral-950 hover:underline">
            Ver os números
          </summary>
          <table className="mt-2 w-full text-sm">
            <caption className="sr-only">{config.label} por exame, em mg/dL</caption>
            <tbody className="divide-y divide-neutral-200/80">
              {pontos
                .slice()
                .reverse()
                .map((p, i) => (
                  <tr key={`${p.data}-${i}`}>
                    <th scope="row" className="py-1.5 text-left font-normal text-neutral-500 tabular-nums">
                      {dataLonga(p.data)}
                      {!p.jejum && " · sem jejum"}
                    </th>
                    <td className="numero py-1.5 text-right font-medium text-neutral-950">
                      {numeroLipidico(p.valor)}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </details>
      )}
    </div>
  );
}

function Dica({ active, payload }: { active?: boolean; payload?: { payload: Ponto }[] }) {
  const ponto = payload?.[0]?.payload;
  if (!active || !ponto) return null;
  return (
    <div className="rounded-xl bg-white px-3 py-2 shadow-[0_8px_24px_-12px_rgba(12,18,20,.3)] ring-1 ring-neutral-200/90">
      <p className="rotulo text-neutral-400">{dataLonga(ponto.data)}</p>
      <p className="numero mt-1 text-base leading-none font-semibold text-neutral-950">
        {numeroLipidico(ponto.valor)}
        <span className="ml-1 font-sans text-xs font-medium tracking-normal text-neutral-400">
          mg/dL
        </span>
      </p>
      {!ponto.jejum && <p className="mt-1 text-xs text-neutral-500">sem jejum</p>}
    </div>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";

import { CHIP_SEMAFORO } from "@/components/aluno/CardIndicador";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { SemaforoStatus } from "@/lib/types";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import {
  CONFIG_LIPIDICA,
  LIMITES_LIPIDICOS,
  MEDIDAS_LIPIDICAS,
  numeroLipidico,
  statusLipidico,
  type MedidaLipidica,
  type RegistroColesterol as Registro,
} from "@/lib/utils/colesterol";
import { lerNumero } from "@/lib/utils/indicadores";
import { SEMAFORO_CONFIG } from "@/lib/utils/semaforo";

const CARD = "flex flex-col gap-5 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90 md:p-6";
const PILULA =
  "h-11 flex-1 rounded-full text-sm font-medium transition-all duration-200 active:scale-[.98] sm:w-36 sm:flex-none";
const PONTO: Record<SemaforoStatus, string> = {
  verde: "bg-saude-verde",
  amarelo: "bg-saude-amarelo",
  vermelho: "bg-saude-vermelho",
};

const VAZIO = Object.fromEntries(MEDIDAS_LIPIDICAS.map((m) => [m, ""])) as Record<
  MedidaLipidica,
  string
>;

const dataBR = (iso: string) =>
  format(new Date(`${iso}T12:00:00Z`), "d 'de' MMM yyyy", { locale: ptBR });

interface RegistroColesterolProps {
  alunoId: string;
  registros: Registro[];
  hoje: string;
  indisponivel: boolean;
}

export function RegistroColesterol({
  alunoId,
  registros,
  hoje,
  indisponivel,
}: RegistroColesterolProps) {
  const router = useRouter();
  const [valores, setValores] = useState(VAZIO);
  const [data, setData] = useState(hoje);
  const [jejum, setJejum] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);
  const [salvo, setSalvo] = useState(false);

  if (indisponivel) {
    return (
      <div className="flex items-start gap-3.5 rounded-2xl bg-card px-5 py-4 ring-1 ring-neutral-200/90">
        <AlertCircle className="mt-0.5 size-5 shrink-0 text-neutral-400" strokeWidth={1.8} aria-hidden />
        <p className="text-sm leading-relaxed text-neutral-500">
          O registro de colesterol ainda está sendo ativado pelo centro. Volte daqui a pouco.
        </p>
      </div>
    );
  }

  async function salvar(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro(null);
    setSalvo(false);

    const lidos = {} as Record<MedidaLipidica, number | null>;
    for (const medida of MEDIDAS_LIPIDICAS) {
      const texto = valores[medida].trim();
      if (!texto) {
        lidos[medida] = null;
        continue;
      }
      const n = lerNumero(texto);
      const [min, max] = LIMITES_LIPIDICOS[medida];
      if (n === null || n < min || n > max) {
        return setErro(
          `${CONFIG_LIPIDICA[medida].curto}: confira o número no laudo (entre ${min} e ${max} mg/dL).`
        );
      }
      lidos[medida] = n;
    }

    if (MEDIDAS_LIPIDICAS.every((m) => lidos[m] === null)) {
      return setErro("Preencha ao menos um valor do exame.");
    }
    if (!data || data > hoje) return setErro("Informe a data da coleta (hoje ou antes).");

    setSalvando(true);
    const { error } = await createClient()
      .from("colesterol_registros")
      .insert({ aluno_id: alunoId, data, jejum, ...lidos });
    setSalvando(false);

    if (error) {
      return setErro("Não conseguimos salvar o exame. Confira a conexão e tente de novo.");
    }
    setValores(VAZIO);
    setSalvo(true);
    router.refresh();
  }

  const ultimo = registros[0];

  return (
    <div className="flex flex-col gap-5">
      {/* ── Último exame ─────────────────────────────────────────── */}
      {ultimo && (
        <div className="flex flex-col gap-3">
          <p className="rotulo text-neutral-400">
            Último exame · {dataBR(ultimo.data)}
            {!ultimo.jejum && " · sem jejum"}
          </p>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
            {MEDIDAS_LIPIDICAS.map((medida) => {
              const valor = ultimo[medida];
              const status = valor != null ? statusLipidico(medida, valor, ultimo.jejum) : null;
              return (
                <div
                  key={medida}
                  className="flex flex-col gap-2 rounded-2xl bg-card p-4 ring-1 ring-neutral-200/90"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[13px] font-medium text-neutral-500">
                      {CONFIG_LIPIDICA[medida].curto}
                    </p>
                    {status && (
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-[11px] font-semibold",
                          CHIP_SEMAFORO[status]
                        )}
                      >
                        {SEMAFORO_CONFIG[status].label}
                      </span>
                    )}
                  </div>
                  <p className="numero text-[28px] leading-none font-semibold text-neutral-950">
                    {valor != null ? numeroLipidico(valor) : "-"}
                    {valor != null && (
                      <span className="ml-1 font-sans text-xs font-medium tracking-normal text-neutral-400">
                        mg/dL
                      </span>
                    )}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Registrar ────────────────────────────────────────────── */}
      <form onSubmit={salvar} className={CARD} noValidate>
        <div>
          <h3 className="text-lg font-semibold tracking-[-0.02em] text-neutral-950">
            Registrar exame de sangue
          </h3>
          <p className="mt-0.5 text-sm text-neutral-500">
            Copie do laudo o que tiver. Não precisa preencher os quatro.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-[minmax(0,13rem)_auto] sm:items-end">
          <div className="flex flex-col gap-2">
            <Label htmlFor="col-data" className="text-neutral-700">
              Data da coleta
            </Label>
            <Input
              id="col-data"
              type="date"
              value={data}
              max={hoje}
              onChange={(e) => setData(e.target.value)}
              disabled={salvando}
              className="h-12 px-3.5 text-base"
            />
          </div>
          <div className="flex flex-col gap-2">
            <p id="col-jejum" className="text-sm font-medium text-neutral-700">
              Estava em jejum?
            </p>
            <div role="group" aria-labelledby="col-jejum" className="flex gap-2">
              {[
                { texto: "Em jejum", valor: true },
                { texto: "Sem jejum", valor: false },
              ].map(({ texto, valor }) => (
                <button
                  key={texto}
                  type="button"
                  onClick={() => setJejum(valor)}
                  aria-pressed={jejum === valor}
                  disabled={salvando}
                  className={cn(
                    PILULA,
                    jejum === valor
                      ? "bg-grafite text-white"
                      : "bg-neutral-50 text-neutral-700 ring-1 ring-neutral-200 hover:bg-neutral-100"
                  )}
                >
                  {texto}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-x-3 gap-y-4 md:grid-cols-4">
          {MEDIDAS_LIPIDICAS.map((medida) => (
            <div key={medida} className="flex flex-col gap-2">
              <Label htmlFor={`col-${medida}`} className="text-neutral-700">
                {CONFIG_LIPIDICA[medida].campo}
              </Label>
              <div className="relative">
                <Input
                  id={`col-${medida}`}
                  inputMode="decimal"
                  value={valores[medida]}
                  onChange={(e) => setValores((v) => ({ ...v, [medida]: e.target.value }))}
                  placeholder={CONFIG_LIPIDICA[medida].exemplo}
                  disabled={salvando}
                  className="numero h-12 pr-16 pl-3.5 text-base"
                />
                <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-xs font-medium text-neutral-400">
                  mg/dL
                </span>
              </div>
            </div>
          ))}
        </div>

        {erro && (
          <p role="alert" className="flex items-start gap-2 text-sm text-saude-vermelho">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            {erro}
          </p>
        )}
        {salvo && !erro && (
          <p role="status" className="flex items-start gap-2 text-sm font-medium text-saude-verde">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0" aria-hidden />
            Exame registrado. O gráfico está em Evolução.
          </p>
        )}

        <Button
          type="submit"
          disabled={salvando}
          className="h-12 w-full rounded-full text-base font-semibold sm:w-auto sm:self-start sm:px-8"
        >
          {salvando ? (
            <>
              <Loader2 className="size-5 animate-spin" aria-hidden />
              Salvando...
            </>
          ) : (
            "Salvar exame"
          )}
        </Button>
      </form>

      {/* ── Referências ──────────────────────────────────────────── */}
      <details className="group rounded-2xl bg-card ring-1 ring-neutral-200/90">
        <summary className="cursor-pointer px-5 py-4 text-[15px] font-semibold text-neutral-950">
          Faixas de referência (mg/dL)
        </summary>
        <ul className="flex flex-col divide-y divide-neutral-200/80 border-t border-neutral-200/80">
          {MEDIDAS_LIPIDICAS.map((medida) => {
            const { referencia } = CONFIG_LIPIDICA[medida];
            const trechos = (
              [
                ["verde", referencia.verde],
                ["amarelo", referencia.amarelo],
                ["vermelho", referencia.vermelho],
              ] as const
            ).filter(([, texto]) => texto);
            return (
              <li key={medida} className="flex flex-col gap-2 px-5 py-3.5 md:flex-row md:gap-6">
                <p className="text-[15px] font-semibold text-neutral-950 md:w-44 md:shrink-0">
                  {CONFIG_LIPIDICA[medida].label}
                </p>
                <dl className="grid flex-1 gap-1.5 sm:grid-cols-3 sm:gap-4">
                  {trechos.map(([status, texto]) => (
                    <div key={status} className="flex items-center gap-2 text-sm">
                      <span aria-hidden className={cn("size-2 shrink-0 rounded-full", PONTO[status])} />
                      <dt className="sr-only">{SEMAFORO_CONFIG[status].label}</dt>
                      <dd className="text-neutral-600 tabular-nums">{texto}</dd>
                    </div>
                  ))}
                </dl>
              </li>
            );
          })}
        </ul>
        <p className="border-t border-neutral-200/80 px-5 py-3.5 text-[13px] leading-relaxed text-neutral-500">
          Referências para adultos da Sociedade Brasileira de Cardiologia. A meta de LDL
          muda conforme o risco de cada pessoa e quem define é o seu médico.
        </p>
      </details>
    </div>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, Loader2 } from "lucide-react";

import { CHIP_SEMAFORO } from "@/components/aluno/CardIndicador";
import { FaixaSemaforo } from "@/components/shared/FaixaSemaforo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import { alturaEmMetros, lerNumero } from "@/lib/utils/indicadores";
import { hojeISO } from "@/lib/utils/datas";
import { calcularSemaforo, SEMAFORO_CONFIG } from "@/lib/utils/semaforo";
import {
  calcularComposicao,
  DOBRAS,
  IDADE_VALIDADA,
  idadeNaData,
  type DobraId,
  type Sexo,
} from "@/lib/utils/composicao";

const CAMPOS = [
  { id: "peso", rotulo: "Peso", unidade: "kg", exemplo: "72,5" },
  { id: "altura", rotulo: "Altura", unidade: "m ou cm", exemplo: "1,75" },
  {
    id: "percentual_gordura",
    rotulo: "% de gordura",
    unidade: "%",
    exemplo: "24",
  },
  {
    id: "massa_muscular",
    rotulo: "Massa muscular",
    unidade: "kg",
    exemplo: "32",
  },
  {
    id: "circunferencia_cintura",
    rotulo: "Cintura",
    unidade: "cm",
    exemplo: "88",
  },
  {
    id: "circunferencia_quadril",
    rotulo: "Quadril",
    unidade: "cm",
    exemplo: "102",
  },
] as const;

type CampoId = (typeof CAMPOS)[number]["id"];

const DOBRAS_VAZIAS = Object.fromEntries(DOBRAS.map(({ id }) => [id, ""])) as Record<
  DobraId,
  string
>;

// Acima disso o adipômetro clínico não mede; é quase sempre vírgula esquecida.
const DOBRA_MAXIMA = 80;

const PILULA =
  "h-12 flex-1 rounded-full text-sm font-medium transition-all duration-200 active:scale-[.98] sm:w-32 sm:flex-none";
const PILULA_MARCADA = "bg-grafite text-white";
const PILULA_LIVRE =
  "bg-neutral-50 text-neutral-700 ring-1 ring-neutral-200 hover:bg-neutral-100";

const numeroBR = (valor: number, casas = 1) =>
  valor.toLocaleString("pt-BR", { minimumFractionDigits: casas, maximumFractionDigits: casas });

const CARD = "flex flex-col gap-5 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90 md:p-6";
const TITULO_CARD = "text-lg font-semibold tracking-[-0.02em] text-neutral-950";
const TEXTAREA =
  "w-full resize-none rounded-[14px] border border-input bg-card px-3.5 py-3 text-base transition-colors outline-none placeholder:text-neutral-400 hover:border-neutral-300 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-60";

interface FormularioAvaliacaoProps {
  professorId: string;
  alunoId: string;
  alunoNome: string;
  /** `profiles.data_nascimento`, para sugerir a idade na data da avaliação. */
  alunoNascimento: string | null;
  /** Sexo da última avaliação com dobras, para não perguntar de novo. */
  sexoAnterior: Sexo | null;
}

export function FormularioAvaliacao({
  professorId,
  alunoId,
  alunoNome,
  alunoNascimento,
  sexoAnterior,
}: FormularioAvaliacaoProps) {
  const router = useRouter();

  const [data, setData] = useState(hojeISO());
  const [valores, setValores] = useState<Record<CampoId, string>>({
    peso: "",
    altura: "",
    percentual_gordura: "",
    massa_muscular: "",
    circunferencia_cintura: "",
    circunferencia_quadril: "",
  });
  const [dobras, setDobras] = useState(DOBRAS_VAZIAS);
  const [sexo, setSexo] = useState<Sexo | null>(sexoAnterior);
  // `null` = o professor ainda não mexeu: segue a data de nascimento.
  const [idadeDigitada, setIdadeDigitada] = useState<string | null>(null);
  const [testeForca, setTesteForca] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);

  const peso = lerNumero(valores.peso);
  const metros = alturaEmMetros(lerNumero(valores.altura));
  // Prévia ao vivo: o professor confere o IMC antes de gravar.
  const imc = peso && metros ? peso / (metros * metros) : null;
  const statusImc = imc ? calcularSemaforo("peso", imc) : null;

  const idadeSugerida = alunoNascimento && data ? idadeNaData(alunoNascimento, data) : null;
  const idadeTexto = idadeDigitada ?? (idadeSugerida != null ? String(idadeSugerida) : "");
  const idade = lerNumero(idadeTexto);

  const dobrasLidas = DOBRAS.map(({ id }) => lerNumero(dobras[id]));
  const algumaDobra = DOBRAS.some(({ id }) => dobras[id].trim());
  const dobrasValidas = dobrasLidas.every((n) => n !== null && n > 0 && n <= DOBRA_MAXIMA);
  const idadeValida = idade !== null && Number.isInteger(idade) && idade >= 10 && idade <= 100;

  // Prévia ao vivo da composição, igual ao IMC: só com tudo preenchido.
  const composicao =
    dobrasValidas && idadeValida && sexo
      ? calcularComposicao(
          Object.fromEntries(DOBRAS.map(({ id }, i) => [id, dobrasLidas[i]!])) as Record<
            DobraId,
            number
          >,
          idade!,
          sexo,
          peso && peso > 0 ? peso : null
        )
      : null;
  const composicaoPlausivel =
    composicao !== null && composicao.percentualGordura > 2 && composicao.percentualGordura < 60;
  const foraDaFaixaValidada =
    idadeValida && (idade! < IDADE_VALIDADA.min || idade! > IDADE_VALIDADA.max);

  async function salvar(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro(null);

    if (!data) {
      setErro("Informe a data da avaliação.");
      return;
    }

    // Campo preenchido com algo que não é número positivo sumiria calado.
    const invalido = CAMPOS.find((c) => {
      const texto = valores[c.id as CampoId].trim();
      if (!texto) return false;
      const n = lerNumero(texto);
      return n === null || !Number.isFinite(n) || n <= 0;
    });
    if (invalido) {
      setErro(`${invalido.rotulo}: use só o número, por exemplo ${invalido.exemplo}.`);
      return;
    }

    if (algumaDobra) {
      const dobraRuim = DOBRAS.find((_, i) => {
        const n = dobrasLidas[i];
        return n === null || n <= 0 || n > DOBRA_MAXIMA;
      });
      if (dobraRuim) {
        setErro(
          `Dobra ${dobraRuim.rotulo.toLowerCase()}: preencha as 7 dobras em mm, entre 1 e ${DOBRA_MAXIMA}.`
        );
        return;
      }
      if (!sexo) {
        setErro("Marque o sexo para calcular a composição pelas dobras.");
        return;
      }
      if (!idadeValida) {
        setErro("Informe a idade em anos completos, por exemplo 42.");
        return;
      }
      if (!composicaoPlausivel) {
        setErro("O % de gordura saiu fora do possível. Confira as dobras e a idade.");
        return;
      }
    }

    const preenchidos = Object.values(valores).some((v) => v.trim()) || algumaDobra;
    if (!preenchidos && !testeForca.trim()) {
      setErro("Preencha ao menos uma medida.");
      return;
    }

    setSalvando(true);

    const numerico = (id: CampoId) => lerNumero(valores[id]);
    const arredonda = (valor: number | null, casas: number) =>
      valor == null ? null : Number(valor.toFixed(casas));

    // As colunas das dobras vêm da migração 020. Só entram no insert quando há
    // dobras, para a avaliação comum seguir salvando mesmo antes dela.
    const camposDobras =
      algumaDobra && composicao
        ? {
            protocolo: "jackson_pollock_7",
            sexo,
            idade,
            ...Object.fromEntries(DOBRAS.map(({ id }, i) => [id, dobrasLidas[i]])),
            soma_dobras: arredonda(composicao.somaDobras, 1),
            densidade_corporal: arredonda(composicao.densidade, 5),
            massa_gorda: arredonda(composicao.massaGorda, 1),
            massa_magra: arredonda(composicao.massaMagra, 1),
          }
        : {};

    const { error } = await createClient().from("avaliacoes_fisicas").insert({
      aluno_id: alunoId,
      professor_id: professorId,
      data,
      peso: numerico("peso"),
      // Grava sempre em metros, para o IMC não depender de quem digitou.
      altura: metros,
      imc: imc ? Number(imc.toFixed(1)) : null,
      percentual_gordura: composicao
        ? arredonda(composicao.percentualGordura, 1)
        : numerico("percentual_gordura"),
      massa_muscular: numerico("massa_muscular"),
      circunferencia_cintura: numerico("circunferencia_cintura"),
      circunferencia_quadril: numerico("circunferencia_quadril"),
      teste_forca: testeForca.trim() || null,
      observacoes: observacoes.trim() || null,
      ...camposDobras,
    });

    if (error) {
      setSalvando(false);
      setErro("Não conseguimos salvar a avaliação. Confira a conexão e tente de novo.");
      return;
    }
    // Sem liberar o botão: a navegação já começou e um segundo toque duplicaria.

    router.push(`/alunos/${alunoId}`);
    router.refresh();
  }

  return (
    <form
      onSubmit={salvar}
      className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-6"
      noValidate
    >
      <div className="flex flex-col gap-5">
        {/* ── Medidas ──────────────────────────────────────────────── */}
        <section className={CARD}>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className={TITULO_CARD}>Medidas</h2>
              <p className="mt-0.5 text-sm text-neutral-500">
                Só o que foi medido hoje em {alunoNome.split(" ")[0]}.
              </p>
            </div>
            <div className="flex w-full flex-col gap-2 sm:w-44">
              <Label htmlFor="av-data" className="text-neutral-700">
                Data
              </Label>
              <Input
                id="av-data"
                type="date"
                value={data}
                onChange={(e) => setData(e.target.value)}
                disabled={salvando}
                className="h-12 px-3.5 text-base"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-x-3 gap-y-4 md:grid-cols-3">
            {CAMPOS.map(({ id, rotulo, unidade, exemplo }) => {
              // Com as 7 dobras, o % de gordura sai do cálculo e não se digita.
              const calculado = id === "percentual_gordura" && composicao !== null;
              return (
              <div key={id} className="flex flex-col gap-2">
                <Label htmlFor={`av-${id}`} className="text-neutral-700">
                  {rotulo}
                  {calculado && (
                    <span className="font-normal text-neutral-400"> (pelas dobras)</span>
                  )}
                </Label>
                <div className="relative">
                  <Input
                    id={`av-${id}`}
                    inputMode="decimal"
                    value={
                      calculado ? numeroBR(composicao.percentualGordura) : valores[id]
                    }
                    onChange={(e) =>
                      setValores((atuais) => ({ ...atuais, [id]: e.target.value }))
                    }
                    placeholder={exemplo}
                    disabled={salvando || calculado}
                    className="numero h-12 pr-16 pl-3.5 text-base"
                  />
                  <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-xs font-medium text-neutral-400">
                    {unidade}
                  </span>
                </div>
              </div>
              );
            })}
          </div>
        </section>

        {/* ── Dobras cutâneas ──────────────────────────────────────── */}
        <section className={CARD}>
          <div>
            <h2 className={TITULO_CARD}>Dobras cutâneas</h2>
            <p className="mt-0.5 text-sm text-neutral-500">
              Jackson & Pollock, 7 dobras. Opcional: preencha as sete para calcular a
              composição corporal.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-[auto_minmax(0,9rem)] sm:items-end sm:gap-5">
            <div className="flex flex-col gap-2">
              <p id="av-sexo" className="text-sm font-medium text-neutral-700">
                Sexo
              </p>
              <div role="group" aria-labelledby="av-sexo" className="flex gap-2">
                {(
                  [
                    ["masculino", "Masculino"],
                    ["feminino", "Feminino"],
                  ] as const
                ).map(([valor, texto]) => (
                  <button
                    key={valor}
                    type="button"
                    onClick={() => setSexo(valor)}
                    aria-pressed={sexo === valor}
                    disabled={salvando}
                    className={cn(PILULA, sexo === valor ? PILULA_MARCADA : PILULA_LIVRE)}
                  >
                    {texto}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Label htmlFor="av-idade" className="text-neutral-700">
                Idade
              </Label>
              <div className="relative">
                <Input
                  id="av-idade"
                  inputMode="numeric"
                  value={idadeTexto}
                  onChange={(e) => setIdadeDigitada(e.target.value)}
                  placeholder="42"
                  disabled={salvando}
                  className="numero h-12 pr-14 pl-3.5 text-base"
                />
                <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-xs font-medium text-neutral-400">
                  anos
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-x-3 gap-y-4 md:grid-cols-4">
            {DOBRAS.map(({ id, rotulo }) => (
              <div key={id} className="flex flex-col gap-2">
                <Label htmlFor={`av-${id}`} className="text-neutral-700">
                  {rotulo}
                </Label>
                <div className="relative">
                  <Input
                    id={`av-${id}`}
                    inputMode="decimal"
                    value={dobras[id]}
                    onChange={(e) =>
                      setDobras((atuais) => ({ ...atuais, [id]: e.target.value }))
                    }
                    placeholder="12"
                    disabled={salvando}
                    className="numero h-12 pr-12 pl-3.5 text-base"
                  />
                  <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-xs font-medium text-neutral-400">
                    mm
                  </span>
                </div>
              </div>
            ))}
          </div>

          {foraDaFaixaValidada && algumaDobra && (
            <p className="text-sm text-neutral-500">
              A equação foi validada entre {IDADE_VALIDADA.min} e {IDADE_VALIDADA.max} anos. Fora
              dessa faixa, use o resultado para comparar o aluno com ele mesmo.
            </p>
          )}
        </section>

        {/* ── Observações ──────────────────────────────────────────── */}
        <section className={CARD}>
          <h2 className={TITULO_CARD}>Teste e observações</h2>

          <div className="flex flex-col gap-2">
            <Label htmlFor="av-forca" className="text-neutral-700">
              Teste de força{" "}
              <span className="font-normal text-neutral-400">(opcional)</span>
            </Label>
            <Input
              id="av-forca"
              value={testeForca}
              onChange={(e) => setTesteForca(e.target.value)}
              placeholder="Sentar e levantar: 12 repetições em 30s"
              disabled={salvando}
              className="h-12 px-3.5 text-base"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="av-obs" className="text-neutral-700">
              Observações
            </Label>
            <textarea
              id="av-obs"
              rows={3}
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              placeholder="O que mudou desde a última avaliação e o que ajustar no treino."
              disabled={salvando}
              className={TEXTAREA}
            />
          </div>
        </section>
      </div>

      {/* ── IMC ao vivo + salvar ───────────────────────────────────── */}
      <aside className="flex flex-col gap-4 lg:sticky lg:top-40">
        <div className="flex flex-col gap-3 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90 md:p-6">
          <div className="flex items-center justify-between gap-2">
            <p className="rotulo text-neutral-400">IMC calculado</p>
            {statusImc && (
              <span
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-[11px] font-semibold",
                  CHIP_SEMAFORO[statusImc]
                )}
              >
                {SEMAFORO_CONFIG[statusImc].label}
              </span>
            )}
          </div>

          {imc ? (
            <>
              <p className="numero text-[44px] leading-none font-semibold text-neutral-950" aria-live="polite">
                {imc.toFixed(1).replace(".", ",")}
                <span className="ml-1.5 font-sans text-sm font-medium tracking-normal text-neutral-400">
                  kg/m²
                </span>
              </p>
              <FaixaSemaforo tipo="peso" valor={imc} className="mt-2" />
              <div aria-hidden className="flex justify-between">
                <span className="rotulo text-neutral-400">16</span>
                <span className="rotulo text-neutral-400">25</span>
                <span className="rotulo text-neutral-400">30</span>
                <span className="rotulo text-neutral-400">40</span>
              </div>
            </>
          ) : (
            <p className="text-[15px] leading-relaxed text-neutral-400">
              Preencha peso e altura para ver o IMC aqui, antes de gravar.
            </p>
          )}
        </div>

        {algumaDobra && (
          <div className="flex flex-col gap-4 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90 md:p-6">
            <p className="rotulo text-neutral-400">Composição corporal</p>

            {composicao && composicaoPlausivel ? (
              <>
                <p className="numero text-[44px] leading-none font-semibold text-neutral-950" aria-live="polite">
                  {numeroBR(composicao.percentualGordura)}
                  <span className="ml-1.5 font-sans text-sm font-medium tracking-normal text-neutral-400">
                    % de gordura
                  </span>
                </p>
                <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
                  {(
                    [
                      ["Massa gorda", composicao.massaGorda, "kg", 1],
                      ["Massa magra", composicao.massaMagra, "kg", 1],
                      ["Soma das dobras", composicao.somaDobras, "mm", 1],
                      ["Densidade", composicao.densidade, "g/cm³", 4],
                    ] as const
                  ).map(([rotulo, valor, unidade, casas]) => (
                    <div key={rotulo}>
                      <dt className="rotulo text-neutral-400">{rotulo}</dt>
                      <dd className="numero mt-0.5 text-lg leading-tight font-semibold text-neutral-950">
                        {valor != null ? numeroBR(valor, casas) : "-"}
                        {valor != null && (
                          <span className="ml-1 font-sans text-xs font-medium tracking-normal text-neutral-400">
                            {unidade}
                          </span>
                        )}
                      </dd>
                    </div>
                  ))}
                </dl>
                {composicao.massaGorda == null && (
                  <p className="text-sm text-neutral-500">
                    Preencha o peso para ver massa gorda e massa magra.
                  </p>
                )}
              </>
            ) : composicao ? (
              <p className="text-[15px] leading-relaxed text-saude-vermelho">
                O resultado saiu fora do possível. Confira as dobras e a idade.
              </p>
            ) : (
              <p className="text-[15px] leading-relaxed text-neutral-400">
                Preencha sexo, idade e as 7 dobras para ver o % de gordura, a massa gorda e a
                massa magra.
              </p>
            )}
          </div>
        )}

        {erro && (
          <p role="alert" className="flex items-start gap-2 text-sm text-saude-vermelho">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            {erro}
          </p>
        )}

        <Button
          type="submit"
          disabled={salvando}
          className="h-12 w-full rounded-full text-base font-semibold"
        >
          {salvando ? (
            <>
              <Loader2 className="size-5 animate-spin" aria-hidden />
              Salvando...
            </>
          ) : (
            "Lançar avaliação"
          )}
        </Button>
      </aside>
    </form>
  );
}

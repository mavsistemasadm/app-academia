"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Bandage, Check, Loader2 } from "lucide-react";

import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import { hojeISO } from "@/lib/utils/datas";
import {
  ESTILO_INTENSIDADE,
  faixaIntensidade,
  ondeDoi,
  type Lesao,
} from "@/lib/utils/lesoes";

const dataBR = (iso: string) =>
  format(new Date(`${iso.slice(0, 10)}T12:00:00Z`), "d 'de' MMM yyyy", { locale: ptBR });

/** Destaque das lesões ativas — usado na ficha e no formulário de treino. */
export function AvisoLesoesAtivas({
  lesoes,
  nomeAluno,
  className,
}: {
  lesoes: Lesao[];
  nomeAluno?: string;
  className?: string;
}) {
  if (lesoes.length === 0) return null;

  return (
    <div
      role="note"
      className={cn(
        "flex items-start gap-3 rounded-2xl bg-saude-amarelo-light px-4 py-3.5 ring-1 ring-saude-amarelo/40 md:px-5",
        className
      )}
    >
      <Bandage className="mt-0.5 size-5 shrink-0 text-[#b45309]" strokeWidth={1.9} aria-hidden />
      <div className="min-w-0">
        <p className="text-[15px] font-semibold text-neutral-950">
          {lesoes.length === 1 ? "Lesão ativa" : `${lesoes.length} lesões ativas`}
          {nomeAluno ? ` de ${nomeAluno.split(" ")[0]}` : ""}
        </p>
        <ul className="mt-1 flex flex-col gap-0.5 text-sm leading-relaxed text-neutral-700">
          {lesoes.map((lesao) => (
            <li key={lesao.id}>
              <span className="font-medium">{ondeDoi(lesao)}</span>, dor {lesao.intensidade}/10
              {" desde "}
              {dataBR(lesao.data)}
              {lesao.descricao ? `. ${lesao.descricao}` : ""}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

interface LesoesDoAlunoProps {
  professorId: string;
  lesoes: Lesao[];
}

/** Histórico de lesões na ficha, com "Marcar como resolvida". */
export function LesoesDoAluno({ professorId, lesoes }: LesoesDoAlunoProps) {
  const router = useRouter();
  const [resolvendo, setResolvendo] = useState<string | null>(null);
  const [erro, setErro] = useState<string | null>(null);

  async function resolver(lesao: Lesao) {
    setErro(null);
    setResolvendo(lesao.id);
    const { error } = await createClient()
      .from("lesoes")
      .update({
        status: "resolvida",
        resolvida_em: new Date().toISOString(),
        resolvida_por: professorId,
      })
      .eq("id", lesao.id);
    setResolvendo(null);

    if (error) {
      setErro("Não conseguimos marcar como resolvida. Tente de novo.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-2">
      <ul className="divide-y divide-neutral-200/80 overflow-hidden rounded-2xl bg-card ring-1 ring-neutral-200/90">
        {lesoes.map((lesao) => {
          const ativa = lesao.status === "ativa";
          const estilo = ESTILO_INTENSIDADE[faixaIntensidade(lesao.intensidade)];

          return (
            <li
              key={lesao.id}
              className={cn(
                "flex flex-col gap-2 px-5 py-4 sm:flex-row sm:items-start sm:justify-between sm:gap-4",
                ativa && "bg-saude-amarelo-light/40"
              )}
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-[15px] font-semibold text-neutral-950">{ondeDoi(lesao)}</p>
                  <span
                    className={cn(
                      "rounded-full px-2.5 py-0.5 text-[11px] font-semibold",
                      ativa ? estilo.chip : "bg-neutral-100 text-neutral-500"
                    )}
                  >
                    {ativa ? `${lesao.intensidade}/10 · ${estilo.rotulo}` : "Resolvida"}
                  </span>
                </div>
                <p className="rotulo mt-1 text-neutral-400">
                  Desde {dataBR(lesao.data)}
                  {!ativa && lesao.resolvida_em
                    ? ` · resolvida em ${dataBR(hojeISO(new Date(lesao.resolvida_em)))}`
                    : ""}
                  {!ativa ? ` · dor ${lesao.intensidade}/10` : ""}
                </p>
                {lesao.descricao && (
                  <p className="mt-1 text-sm leading-relaxed text-neutral-600">{lesao.descricao}</p>
                )}
              </div>

              {ativa && (
                <button
                  type="button"
                  onClick={() => resolver(lesao)}
                  disabled={resolvendo !== null}
                  className="flex h-10 shrink-0 items-center justify-center gap-1.5 rounded-full px-4 text-sm font-semibold text-neutral-700 ring-1 ring-neutral-200 transition-colors hover:bg-neutral-50 disabled:opacity-60"
                >
                  {resolvendo === lesao.id ? (
                    <Loader2 className="size-4 animate-spin" aria-hidden />
                  ) : (
                    <Check className="size-4" aria-hidden />
                  )}
                  Marcar como resolvida
                </button>
              )}
            </li>
          );
        })}
      </ul>
      {erro && (
        <p role="alert" className="text-sm text-saude-vermelho">
          {erro}
        </p>
      )}
    </div>
  );
}

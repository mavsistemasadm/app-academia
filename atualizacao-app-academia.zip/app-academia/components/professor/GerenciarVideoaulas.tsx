"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, Eye, EyeOff, Loader2, Pencil, Trash2 } from "lucide-react";

import { ChipTipo } from "@/components/shared/FiltroTipo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";
import { interpretarVideo } from "@/lib/utils/video";
import {
  NOME_TIPO_VIDEOAULA,
  TIPOS_VIDEOAULA,
  formatarMinutos,
  type TipoVideoaula,
  type Videoaula,
} from "@/lib/utils/videoaulas";

const CARD = "flex flex-col gap-5 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90 md:p-6";
const TEXTAREA =
  "w-full resize-none rounded-[14px] border border-input bg-card px-3.5 py-3 text-base transition-colors outline-none placeholder:text-neutral-400 hover:border-neutral-300 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-60";
const BOTAO_ICONE =
  "flex size-10 items-center justify-center rounded-full text-neutral-500 transition-colors hover:bg-neutral-100 hover:text-neutral-950 disabled:opacity-40";

interface Rascunho {
  id: string | null;
  titulo: string;
  url: string;
  descricao: string;
  duracao: string;
  tipo: TipoVideoaula | null;
}

const VAZIO: Rascunho = { id: null, titulo: "", url: "", descricao: "", duracao: "", tipo: null };

interface GerenciarVideoaulasProps {
  videoaulas: Videoaula[];
  indisponivel: boolean;
}

export function GerenciarVideoaulas({ videoaulas, indisponivel }: GerenciarVideoaulasProps) {
  const router = useRouter();
  const [rascunho, setRascunho] = useState<Rascunho>(VAZIO);
  const [erro, setErro] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);
  const [mexendo, setMexendo] = useState<string | null>(null);

  if (indisponivel) {
    return (
      <div className="flex items-start gap-3.5 rounded-2xl bg-card px-5 py-4 ring-1 ring-neutral-200/90">
        <AlertCircle className="mt-0.5 size-5 shrink-0 text-neutral-400" strokeWidth={1.8} aria-hidden />
        <p className="text-sm leading-relaxed text-neutral-500">
          A biblioteca de videoaulas ainda não foi ativada no banco (migração 024).
        </p>
      </div>
    );
  }

  const mudar = (campos: Partial<Rascunho>) => setRascunho((r) => ({ ...r, ...campos }));
  const linkOk = rascunho.url.trim() ? Boolean(interpretarVideo(rascunho.url)) : null;

  async function salvar(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErro(null);

    const titulo = rascunho.titulo.trim();
    if (titulo.length < 2) return setErro("Dê um título à aula.");
    if (!interpretarVideo(rascunho.url)) {
      return setErro("Cole um link do YouTube ou do Vimeo (ou de um arquivo de vídeo).");
    }
    if (!rascunho.tipo) return setErro("Escolha o tipo da aula.");

    let duracao: number | null = null;
    if (rascunho.duracao.trim()) {
      duracao = Number(rascunho.duracao.trim());
      if (!Number.isInteger(duracao) || duracao < 1 || duracao > 300) {
        return setErro("Duração: só os minutos, por exemplo 15.");
      }
    }

    const dados = {
      titulo,
      url: rascunho.url.trim(),
      descricao: rascunho.descricao.trim() || null,
      duracao_minutos: duracao,
      tipo: rascunho.tipo,
    };

    setSalvando(true);
    const supabase = createClient();
    const { error } = rascunho.id
      ? await supabase.from("videoaulas").update(dados).eq("id", rascunho.id)
      : await supabase.from("videoaulas").insert(dados);
    setSalvando(false);

    if (error) return setErro("Não conseguimos salvar a aula. Tente de novo.");
    setRascunho(VAZIO);
    router.refresh();
  }

  async function alternarVisivel(aula: Videoaula) {
    setMexendo(aula.id);
    const { error } = await createClient()
      .from("videoaulas")
      .update({ ativo: !aula.ativo })
      .eq("id", aula.id);
    setMexendo(null);
    if (error) return setErro("Não conseguimos mudar a visibilidade. Tente de novo.");
    router.refresh();
  }

  async function excluir(aula: Videoaula) {
    if (!window.confirm(`Excluir "${aula.titulo}"? Os alunos deixam de ver a aula.`)) return;
    setMexendo(aula.id);
    const { error } = await createClient().from("videoaulas").delete().eq("id", aula.id);
    setMexendo(null);
    if (error) return setErro("Não conseguimos excluir. Tente de novo.");
    if (rascunho.id === aula.id) setRascunho(VAZIO);
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-6 md:gap-8">
      <form onSubmit={salvar} className={CARD} noValidate>
        <h2 className="text-lg font-semibold tracking-[-0.02em] text-neutral-950">
          {rascunho.id ? "Editar videoaula" : "Nova videoaula"}
        </h2>

        <div className="flex flex-col gap-2">
          <Label htmlFor="va-titulo" className="text-neutral-700">Título</Label>
          <Input
            id="va-titulo"
            value={rascunho.titulo}
            onChange={(e) => mudar({ titulo: e.target.value })}
            placeholder="Mobilidade de quadril para o dia a dia"
            maxLength={120}
            disabled={salvando}
            className="h-12 px-3.5 text-base"
          />
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="va-url" className="flex items-center justify-between gap-2 text-neutral-700">
            Link do vídeo
            {linkOk !== null && (
              <span
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-[11px] font-semibold",
                  linkOk
                    ? "bg-saude-verde-light text-[#15803d]"
                    : "bg-saude-amarelo-light text-[#b45309]"
                )}
              >
                {linkOk ? "Vídeo reconhecido" : "Link não reconhecido"}
              </span>
            )}
          </Label>
          <Input
            id="va-url"
            value={rascunho.url}
            onChange={(e) => mudar({ url: e.target.value })}
            placeholder="https://youtu.be/…"
            inputMode="url"
            disabled={salvando}
            className="h-12 px-3.5 text-base"
          />
        </div>

        <fieldset className="flex flex-col gap-2" disabled={salvando}>
          <legend className="mb-2 text-sm leading-none font-medium text-neutral-700">Tipo</legend>
          <div className="flex flex-wrap gap-1.5">
            {TIPOS_VIDEOAULA.map((tipo) => (
              <button
                key={tipo}
                type="button"
                onClick={() => mudar({ tipo })}
                aria-pressed={rascunho.tipo === tipo}
                className={cn(
                  "h-11 rounded-full px-4 text-sm font-semibold transition-all duration-200 active:scale-[.96]",
                  rascunho.tipo === tipo
                    ? "bg-grafite text-white"
                    : "bg-neutral-50 text-neutral-600 ring-1 ring-neutral-200 hover:bg-neutral-100"
                )}
              >
                {NOME_TIPO_VIDEOAULA[tipo]}
              </button>
            ))}
          </div>
        </fieldset>

        <div className="flex flex-col gap-2 sm:w-40">
          <Label htmlFor="va-duracao" className="text-neutral-700">
            Duração <span className="font-normal text-neutral-400">(opcional)</span>
          </Label>
          <div className="relative">
            <Input
              id="va-duracao"
              inputMode="numeric"
              value={rascunho.duracao}
              onChange={(e) => mudar({ duracao: e.target.value })}
              placeholder="15"
              disabled={salvando}
              className="numero h-12 pr-12 pl-3.5 text-base"
            />
            <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-xs font-medium text-neutral-400">
              min
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="va-descricao" className="text-neutral-700">
            Descrição <span className="font-normal text-neutral-400">(opcional)</span>
          </Label>
          <textarea
            id="va-descricao"
            rows={3}
            maxLength={1000}
            value={rascunho.descricao}
            onChange={(e) => mudar({ descricao: e.target.value })}
            placeholder="Para quem é, o que precisa ter em casa, cuidados."
            disabled={salvando}
            className={TEXTAREA}
          />
        </div>

        {erro && (
          <p role="alert" className="flex items-start gap-2 text-sm text-saude-vermelho">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            {erro}
          </p>
        )}

        <div className="flex flex-col gap-2 sm:flex-row">
          <Button
            type="submit"
            disabled={salvando}
            className="h-12 w-full rounded-full px-8 text-base font-semibold sm:w-auto"
          >
            {salvando ? (
              <>
                <Loader2 className="size-5 animate-spin" aria-hidden />
                Salvando...
              </>
            ) : rascunho.id ? (
              "Salvar alterações"
            ) : (
              "Publicar aula"
            )}
          </Button>
          {rascunho.id && (
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setRascunho(VAZIO);
                setErro(null);
              }}
              disabled={salvando}
              className="h-12 w-full rounded-full px-6 sm:w-auto"
            >
              Cancelar
            </Button>
          )}
        </div>
      </form>

      <section className="flex flex-col gap-3.5">
        <h2 className="text-lg font-semibold tracking-[-0.02em] text-neutral-950 md:text-xl">
          Publicadas
        </h2>
        {videoaulas.length === 0 ? (
          <p className="rounded-2xl bg-card px-5 py-8 text-center text-[15px] text-neutral-500 ring-1 ring-neutral-200/90">
            Nenhuma aula ainda. A primeira aparece aqui assim que você publicar.
          </p>
        ) : (
          <ul className="divide-y divide-neutral-200/80 overflow-hidden rounded-2xl bg-card ring-1 ring-neutral-200/90">
            {videoaulas.map((aula) => {
              const duracao = formatarMinutos(aula.duracao_minutos);
              return (
                <li key={aula.id} className="flex items-center gap-3 px-4 py-3.5 md:px-5">
                  <div className={cn("min-w-0 flex-1", !aula.ativo && "opacity-55")}>
                    <p className="truncate text-[15px] font-semibold text-neutral-950">{aula.titulo}</p>
                    <p className="mt-1 flex flex-wrap items-center gap-2">
                      <ChipTipo>{NOME_TIPO_VIDEOAULA[aula.tipo]}</ChipTipo>
                      {duracao && <span className="rotulo text-neutral-400">{duracao}</span>}
                      {!aula.ativo && <span className="rotulo text-neutral-500">Oculta</span>}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-0.5">
                    <button
                      type="button"
                      aria-label={`Editar ${aula.titulo}`}
                      onClick={() => {
                        setErro(null);
                        setRascunho({
                          id: aula.id,
                          titulo: aula.titulo,
                          url: aula.url,
                          descricao: aula.descricao ?? "",
                          duracao: aula.duracao_minutos?.toString() ?? "",
                          tipo: aula.tipo,
                        });
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      disabled={mexendo !== null}
                      className={BOTAO_ICONE}
                    >
                      <Pencil className="size-4" aria-hidden />
                    </button>
                    <button
                      type="button"
                      aria-label={aula.ativo ? `Ocultar ${aula.titulo} dos alunos` : `Mostrar ${aula.titulo} aos alunos`}
                      onClick={() => alternarVisivel(aula)}
                      disabled={mexendo !== null}
                      className={BOTAO_ICONE}
                    >
                      {mexendo === aula.id ? (
                        <Loader2 className="size-4 animate-spin" aria-hidden />
                      ) : aula.ativo ? (
                        <EyeOff className="size-4" aria-hidden />
                      ) : (
                        <Eye className="size-4" aria-hidden />
                      )}
                    </button>
                    <button
                      type="button"
                      aria-label={`Excluir ${aula.titulo}`}
                      onClick={() => excluir(aula)}
                      disabled={mexendo !== null}
                      className={cn(BOTAO_ICONE, "hover:bg-saude-vermelho-light hover:text-saude-vermelho")}
                    >
                      <Trash2 className="size-4" aria-hidden />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

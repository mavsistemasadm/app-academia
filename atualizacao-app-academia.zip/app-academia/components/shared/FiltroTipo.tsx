import Link from "next/link";

import { cn } from "@/lib/utils";

interface FiltroTipoProps<T extends string> {
  /** Rota da própria tela; o filtro vai na query `?tipo=`. */
  caminho: string;
  opcoes: readonly T[];
  nomes: Record<T, string>;
  atual: T | null;
  rotulo?: string;
}

/**
 * Pílulas de filtro por tipo. São links, não estado: o filtro sobrevive ao
 * recarregar, dá para compartilhar e a página filtra no servidor.
 */
export function FiltroTipo<T extends string>({
  caminho,
  opcoes,
  nomes,
  atual,
  rotulo = "Filtrar por tipo",
}: FiltroTipoProps<T>) {
  const pilula =
    "flex h-10 shrink-0 items-center rounded-full px-4 text-sm font-semibold transition-all duration-200 active:scale-[.97]";
  const marcada = "bg-grafite text-white";
  const livre = "bg-card text-neutral-600 ring-1 ring-neutral-200 hover:bg-neutral-50";

  return (
    <nav aria-label={rotulo} className="-mx-4 overflow-x-auto px-4 md:mx-0 md:px-0">
      <ul className="flex gap-1.5">
        <li>
          <Link
            href={caminho}
            aria-current={atual === null ? "page" : undefined}
            className={cn(pilula, atual === null ? marcada : livre)}
          >
            Todos
          </Link>
        </li>
        {opcoes.map((opcao) => (
          <li key={opcao}>
            <Link
              href={`${caminho}?tipo=${opcao}`}
              aria-current={atual === opcao ? "page" : undefined}
              className={cn(pilula, atual === opcao ? marcada : livre)}
            >
              {nomes[opcao]}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

/** Etiqueta discreta de tipo, ao lado de nomes de treino e exercício. */
export function ChipTipo({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "rotulo inline-flex shrink-0 items-center rounded-full bg-neutral-100 px-2 py-0.5 text-[10px] text-neutral-600",
        className
      )}
    >
      {children}
    </span>
  );
}

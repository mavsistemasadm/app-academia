# CENTRAL DE SAÚDE CONECTADA
## Instruções para o Claude no VS Code

---

## O QUE É ESSE PROJETO

PWA (Progressive Web App) de saúde para um centro de treinamento personalizado que atende populações especiais: diabéticos, hipertensos, 60+, colesterol, menopausa, performance, adolescentes, gestantes, cardiopatas e obesos.

O objetivo central: **o aluno sentir que está sendo cuidado 24h por dia pelo centro**.

---

## STACK

- **Next.js 16** (React 19) com App Router e TypeScript
- **Supabase** — banco PostgreSQL, auth, storage, realtime
- **Tailwind CSS** + **shadcn/ui**
- **Vercel** para deploy
- **Web Push API** para notificações PWA

---

## ESTRUTURA DE PASTAS

Todas as rotas abaixo existem e compilam.

```
app/
  layout.tsx              metadata do PWA + registro do service worker
  manifest.ts             manifest do PWA (rota /manifest.webmanifest)
  offline/                tela mostrada quando não há rede

  (auth)/login            login
  (auth)/cadastro         cadastro (condição clínica é múltipla escolha)

  (aluno)/layout.tsx      Sidebar + BottomNav + barra "visão do aluno"
  (aluno)/home            saudação, check-in, indicadores, treino, humor
  (aluno)/treino          treino do dia, série a série, com portão pré-treino
  (aluno)/indicadores     registro + histórico + faixas de referência
  (aluno)/medicamentos    doses do dia num toque + cadastro
  (aluno)/humor           calendário e distribuição de 30 dias
  (aluno)/evolucao        gráficos (recharts) + avaliações físicas
  (aluno)/hidratacao      copo/garrafa/litro num toque + meta
  (aluno)/bem-estar       respiração guiada e aterramento 5-4-3-2-1
  (aluno)/conquistas      badges derivadas dos dados + streak
  (aluno)/desafios        lista, ranking, progresso e registro do desafio (24)
  (aluno)/agenda          eventos com confirmação + comunicados
  (aluno)/aulas           grade da semana, marcar vaga, próximas e histórico
  (aluno)/anamnese        formulário de entrada de saúde
  (aluno)/perfil          dados, foto, contatos, notificações, relatório
  (aluno)/relatorio       folha mensal para o médico (imprime em PDF)
  (aluno)/familiares      convites de acompanhamento familiar
  (aluno)/acompanhar      visão restrita de quem é familiar de um aluno
  (auth)/familia          conta de familiar criada com o código do convite

  (professor)/layout.tsx  header + abas + botão "ver como aluno"
  (professor)/dashboard   números do dia, alertas realtime, alunos críticos
  (professor)/alunos      lista com busca e filtros por semáforo
  (professor)/alunos/[id] ficha completa do aluno
  (professor)/alunos/[id]/avaliacao   lançar avaliação física
  (professor)/treinos     lista / novo / editar, com upload de vídeo
  (professor)/agenda-professor        eventos e comunicados
  (professor)/presenca    quem está na academia, sumidos, movimento
  (professor)/aulas-professor         grade semanal, inscritos e cancelamento
  (professor)/desafios-professor      cria, convida e acompanha desafios

  chat/                   lista de conversas (fora dos dois grupos)
  chat/[id]               conversa com realtime

  api/push/inscrever      salva/apaga a assinatura de push do usuário
  api/cron/lembretes      medicamento, água, evento e aula — a cada 15 min

components/aluno/    CardIndicador · CardTreino · RegistroHumor ·
                     FormularioIndicador · HistoricoIndicadores ·
                     ExecucaoTreino · PortaoPreTreino · DosesDoDia ·
                     GerenciarMedicamentos · GraficoIndicador ·
                     FormularioPerfil · FormularioAnamnese ·
                     BotaoCheckin · RegistroHidratacao · GuiaRespiracao ·
                     GuiaAterramento · ConfirmarPresenca ·
                     GerenciarFamiliares · AceitarConvite · BotaoImprimir
components/professor/ NavProfessor · CardAluno · ListaAlunos ·
                     AlertasRealtime · FormularioTreino ·
                     FormularioAvaliacao · GerenciarAgenda
components/shared/   BottomNav · Sidebar · AlternarVisao · BotaoSair ·
                     VideoExercicio · JanelaChat ·
                     GerenciarNotificacoes · RegistrarServiceWorker

lib/supabase/  client · server · servico (service role) · perfil ·
               home-aluno · indicadores · treino · medicamentos · humor ·
               evolucao · agenda · chat · presenca · hidratacao ·
               conquistas · familiares · relatorio · professor ·
               painel-professor
lib/utils/     index (cn) · semaforo · indicadores · saudacao · datas ·
               avatares · navegacao · erros-auth · video · bem-estar ·
               presenca (constantes de sumiço — client-safe de propósito)
lib/push/      servidor (envio via web-push, limpa assinatura morta)
```

**Regra de fuso:** nunca use `new Date()` direto para decidir "hoje" ou
"agora" — em produção o servidor roda em UTC. Use `lib/utils/datas.ts`.

**Regra da service role:** `lib/supabase/servico.ts` ignora RLS. Só pode ser
importado de rota de API ou server component — nunca de `"use client"`.

---

## BANCO DE DADOS (SUPABASE)

Tabelas principais:
- `profiles` — usuários (alunos e professores)
- `treinos` — treinos vinculados a aluno + professor
- `exercicios` — exercícios de cada treino com video_url
- `treino_execucoes` — histórico de execuções
- `medicamentos` — medicamentos cadastrados pelo aluno
- `medicamento_confirmacoes` — confirmações de tomada
- `indicadores` — glicemia, pressão, peso, FC, saturação
- `humor_diario` — estado do dia do aluno
- `eventos` — agenda da academia
- `mensagens` — chat professor-aluno
- `alertas_professor` — alertas em tempo real para o professor
- `avaliacoes_fisicas` — avaliações periódicas
- `notificacoes` — comunicados da academia
- `exercicio_execucoes` — cada série marcada pelo aluno (migração 004)
- `checkins` — presença na academia (004)
- `familiares_acesso` — convite e vínculo do familiar (004)
- `anamneses` — histórico de saúde de entrada (004)
- `hidratacao_registros` — copos de água (004)
- `aluno_conquistas` — quando cada badge caiu (004)

**Triggers automáticos**
- Indicador inserido: o banco calcula o semáforo e, se vermelho, cria alerta
  para o professor. O peso é a exceção — sai sempre verde, porque o critério
  real é o IMC e a altura mora em `avaliacoes_fisicas`.
- Humor `enfermo` ou `ansioso`: cria alerta para o professor (004).
- `professor_responsavel()` acha o professor pelo treino ativo e, se o aluno
  ainda não tem treino, cai no professor mais antigo do centro.

**Funções de RLS** (004, todas `security definer` com `search_path` fixo)
- `eh_professor(uid)` — usada pelas policies que dão visão de professor.
  Precisa ser função porque uma policy em `profiles` que consulta `profiles`
  entra em recursão infinita.
- `eh_meu_familiar(dono)` — libera indicadores e check-ins para o familiar.

**Storage**: buckets públicos `avatares`, `exercicios` e `medicamentos`. O
primeiro nível do caminho é o id do dono (`avatares/<uid>/foto.jpg`) — é o
que a policy usa para saber quem pode escrever onde.

---

## REGRAS IMPORTANTES DE DESENVOLVIMENTO

### Segurança
- Nunca expor SUPABASE_SERVICE_ROLE_KEY no frontend
- Usar sempre RLS (Row Level Security) — já configurado no schema
- Aluno só vê seus próprios dados
- Professor vê dados dos seus alunos

### UX
**Linguagem visual completa em `docs/DESIGN.md` — leia antes de mexer em tela.**
- **Mobile-first** — a maioria dos alunos vai usar no celular
- Marca Atitude Vital: fundo névoa `#F3F6F6`, cards brancos com contorno de 1px, grafite `#0F1618` como único destaque escuro, ciano `#00B4CB` na marca e `#0A8FA3` em botão/link (`primary`). Nada de azul.
- Semáforo: verde `#16A34A`, amarelo `#D97706`, vermelho `#DC2626` — mostrado com chip e com a faixa `FaixaSemaforo`
- Fontes: Sora em títulos e números (utilidade `numero`), Inter no texto, Geist Mono em rótulos e horários (utilidade `rotulo`)
- Um destaque por tela; sem ícone em quadradinho colorido; telas internas usam `CabecalhoPagina`
- Logo e ícones saem de `public/Logo.jpg` via `node scripts/gerar_marca.mjs`
- Para avatar 60+ e cardiopata: fontes maiores, botões grandes, menos elementos por tela

### Componentes
- Usar shadcn/ui para componentes base
- Ícones: lucide-react
- Gráficos: recharts
- Datas: date-fns com locale ptBR

### Dados em tempo real
- Usar Supabase Realtime para alertas do professor
- Canal: `alertas_professor` filtrado pelo professor_id

---

## AVATARES / CONDIÇÕES CLÍNICAS

```typescript
type AvatarCondicao =
  | 'diabetico'
  | 'hipertenso'
  | '60+'
  | 'colesterol'
  | 'menopausa'
  | 'performance'
  | 'adolescente'
  | 'gestante'
  | 'cardiopata'
  | 'obesidade'
```

---

## SEMÁFORO — FAIXAS CLÍNICAS

| Indicador  | 🟢 Verde       | 🟡 Amarelo      | 🔴 Vermelho        |
|------------|---------------|-----------------|-------------------|
| Pressão    | < 130/85      | 130–159/85–99   | ≥ 160/100          |
| Glicemia   | 70–125 mg/dL  | 126–199 mg/dL   | ≥ 200 ou < 70      |
| Saturação  | ≥ 95%         | 90–94%          | < 90%              |
| FC         | 50–90 bpm     | 91–100 bpm      | > 100 ou < 50      |
| IMC        | < 25          | 25–29,9         | ≥ 30               |

Os limites exatos seguem a referência clínica: 160/100 já é hipertensão
estágio 2 e 200 mg/dL é o corte diagnóstico da glicemia casual, por isso os
dois caem no vermelho. `lib/utils/semaforo.ts` e o gatilho do banco
(`calcular_semaforo_e_alertar`) usam exatamente esta tabela; mudar um exige
mudar o outro.

**Se vermelho**: criar registro em `alertas_professor` + notificar professor em tempo real.

**Colesterol e triglicerídeos** (migração 023, tabela `colesterol_registros`,
um registro por exame) seguem a SBC para adultos e moram só em
`lib/utils/colesterol.ts` — não há gatilho nem alerta, porque perfil lipídico
não muda de um dia para o outro:

| Medida            | 🟢 Verde | 🟡 Amarelo | 🔴 Vermelho |
|-------------------|---------|-----------|------------|
| Colesterol total  | < 190   | 190–239   | ≥ 240      |
| LDL               | < 130   | 130–159   | ≥ 160      |
| HDL               | ≥ 40    | < 40      | —          |
| Triglic. (jejum)  | < 150   | 150–499   | ≥ 500      |
| Triglic. (sem jejum) | < 175 | 175–499 | ≥ 500      |

---

## MÓDULOS — STATUS DE DESENVOLVIMENTO

Legenda: `[x]` pronto · `[~]` parcial · `[ ]` não começou

**Base**
- [x] Auth (login/cadastro, condição clínica múltipla)
- [x] Home do aluno com saudação, check-in e dados reais
- [x] Alternar visão professor ↔ aluno
- [x] PWA — manifest, service worker, ícones, tela offline

**1. Treino** — [x] aluno marca cada série e registra esforço de 1 a 10 ·
[x] professor cria/edita treinos com upload de vídeo (YouTube, Vimeo ou
arquivo no storage) · [x] tipo (mobilidade, força, cardio, isometria) no treino e
em cada exercício, com filtro `?tipo=` em `/treinos` e em `/treino`
(`lib/utils/tipos-treino.ts`) · [~] depende da migração 021

**2. Indicadores** — [x] registro com semáforo · [x] alerta ao professor pelo
gatilho do banco · [x] realtime no painel

**2b. Colesterol** — [x] o aluno registra o exame (total, LDL, HDL,
triglicerídeos, jejum) em `/indicadores#colesterol` · [x] semáforo SBC ·
[x] um gráfico por medida na Evolução (todos os exames) · [x] tabela e
gráficos no relatório para o médico · [x] último exame na ficha ·
[~] depende da migração 023

**3. Medicamentos** — [x] cadastro com horários e dias · [x] confirmação num
toque · [x] push de dose atrasada · [x] o professor vê as pendências no card
do aluno

**4. Humor** — [x] registro na home · [x] calendário e distribuição de 30 dias

**5. Evolução** — [x] gráficos de linha por indicador · [x] variação contra o
período anterior · [x] treinos por mês

**6. Agenda** — [x] professor cria eventos e comunicados · [x] aluno confirma
presença · [x] push uma hora antes

**7. Chat** — [x] conversa direta com realtime, fora dos grupos de rota

**8. Bem-estar** — [x] três ritmos de respiração guiada · [x] aterramento
5-4-3-2-1 · [~] biblioteca de áudio pronta, faltam as gravações dos sócios

**9. Perfil** — [x] foto, dados, condições, contatos, notificações

**10. Painel do professor** — [x] números do dia · [x] alertas em tempo real
· [x] lista com busca e filtros · [x] ficha completa do aluno

**11. Avaliação física** — [x] lançamento pelo professor com IMC ao vivo ·
[x] comparativo na evolução do aluno · [x] dobras cutâneas Jackson & Pollock 7
com % de gordura (Siri), massa gorda e magra ao vivo (`lib/utils/composicao.ts`);
o aluno vê % de gordura e massas na Evolução, as dobras e a densidade ficam na
ficha · [~] depende da migração 020

**12. Check-in** — [x] entrada e saída num toque · [x] painel de presentes ·
[x] lista de sumidos há 5+ dias · [x] movimento de 30 dias

**13. Alerta pré-treino** — [x] o portão pede o indicador da condição do
aluno antes de liberar o treino; no vermelho, avisa e pede confirmação

**14. Relatório para o médico** — [x] folha mensal com CSS de impressão; o
PDF sai pelo próprio navegador, sem biblioteca

**15. Acompanhamento familiar** — [x] convite por código · [x] visão restrita
a indicadores e frequência · [x] RLS própria · [x] quem recebe o convite cria
uma conta de familiar em `/familia?codigo=` (sem convite do professor; o
e-mail precisa ser o do convite) e fica preso em `/acompanhar` pelo middleware

**16. Conquistas** — [x] nove badges derivadas dos dados · [x] streak de
presença · [x] marca as novas como vistas

**17. Anamnese** — [x] formulário do aluno · [x] o professor lê na ficha ·
[x] professor edita, reordena, arquiva e cria perguntas (`/alunos/anamnese`)
em oito tipos: texto curto e longo, escolha única e múltipla, sim ou não,
número, escala 0 a 10 e data · [~] depende da migração 011

**18. Hidratação** — [x] registro num toque com meta e histórico · [x] push
ao longo do dia

**19. Exames** — [x] upload de PDF/imagem com tipo e data (`/exames`) ·
[x] link público com prazo para o médico (`/exames/compartilhado/[token]`),
que mostra também medições de 90 dias, medicamentos e a anamnese marcada
"vai ao médico"

**20. Convite de aluno** — [x] professor convida por nome e e-mail
(`/alunos/convidar`) · [x] primeira senha em `/definir-senha` · [~] template
de e-mail a configurar no Supabase · o link do convite usa `token_hash` e só é
gasto quando a pessoa salva a senha (o leitor de links do Hotmail gastava o
convite antes) · "já tem acesso" vem de `senha_definida` no user_metadata
(`jaCriouSenha`), não de `last_sign_in_at`

**29. Inativar e excluir aluno** — [x] só admin, no fim da ficha
(`ContaDoAluno` → `/api/alunos`) · [x] inativar bloqueia o login, some das
listas, lembretes, push e e-mail e guarda o histórico; reativa pela mesma
ficha (lista "Inativos" em `/alunos`) · [x] excluir pede o nome completo,
apaga os arquivos do aluno no storage e a conta; o resto cai pela cascata
da 006

**30. Lesões e dores** — [x] o aluno avisa em `/lesoes` (local, lado,
intensidade 0 a 10, descrição, data) · [x] o gatilho `alertar_lesao_nova`
cria alerta `lesao` para o professor responsável (painel, sininho e push
pelos gatilhos da 018) · [x] histórico na ficha com "Marcar como resolvida"
· [x] lesão ativa em destaque no formulário de treino do aluno ·
[~] depende da migração 022

**31. Videoaulas** — [x] o professor cadastra título, link (YouTube, Vimeo
ou arquivo), descrição, duração e tipo em `/videoaulas-professor`, edita,
oculta e exclui (a biblioteca é da casa) · [x] o aluno assiste em
`/videoaulas` com filtro por tipo (os do treino + bem-estar) · [~] depende
da migração 024

**21. Tour guiado** — [x] abre na primeira visita à home (`TourGuiado`,
marca `av-tour-visto-v1` no user_metadata) · `?tour=1` reabre

**22. Sininho** — [x] central de notificações do aluno e do professor com
realtime (`SinoNotificacoes`)

**25. Aulas com hora marcada** — [x] o professor monta a grade semanal
(dia, hora, duração, vagas, local, condições) em `/aulas-professor` ·
[x] o aluno marca e desmarca em `/aulas`, vê as próximas e o histórico ·
[x] a vaga é garantida pelo gatilho `checa_vaga_da_aula`, não pela tela
(dois toques no mesmo segundo não furam o limite) · [x] cancelar uma data
específica avisa a turma · [x] destaque na home, lembrete no sino e push uma
hora antes · aluno não enxerga quem mais marcou; o professor vê a lista

**24. Desafios** — [x] dois tipos: **pontos por hábito** (presença, treino,
indicador, água, medicamento, humor; cada um conta uma vez por dia) e **meta a
alcançar** ("5 km em 30 dias", nas medidas km, minutos, treinos, presenças e
litros) · [x] km é a única medida registrada à mão pelo aluno
(`desafio_registros`); as outras o app soma sozinho · [x] modelos prontos
(`MODELOS` em `lib/utils/desafios.ts`) abrem o formulário preenchido ·
[x] capa e anexo no bucket público `desafios` · [x] aberto a todos ou só
convidados, e o aluno participa de quantos quiser · ranking e progresso saem de
funções `security definer` e mostram só "Maria S.", foto e o número

**26. Equipe** — [x] admin é professor com `eh_admin` (não é papel novo) ·
[x] em `/equipe` o admin convida professor ou admin por e-mail e promove ou
rebaixa quem já está na equipe; e-mail de aluno existente vira professor ·
[x] a equipe nunca fica sem admin · [x] a trava de papel também barra
`eh_admin` pelo app · [x] "Tirar da equipe" desativa a conta (bloqueia o
login, vira aluno inativo, some das listas) e passa treinos, aulas,
desafios, agenda e alertas abertos para o admin que tirou; volta pelo
convite normal da equipe

**27. Central de notificações** — [x] todo aviso vira linha em
`notificacoes_usuario` com os canais sino, push e e-mail · [x] gatilhos do
banco criam os avisos e o pg_net chama `/api/notificacoes/despachar` na hora;
o cron varre o que ficou para trás · [x] e-mail com a marca pelo Resend
(`lib/email`) · [x] rotinas diárias em `lib/notificacoes/rotinas.ts`: sumidos,
doses esquecidas, conquistas e marcos (e-mail motivacional), resumo semanal da
equipe e resumo mensal do aluno · [x] professor liga o push no painel ·
lista completa em `docs/NOTIFICACOES.md` · migração 018 e segredos do Vault
aplicados em 29/09/2026

**28. Vídeo de boas-vindas** — [x] `public/boas-vindas.mp4` (H.264 720p,
convertido do .mov do iPhone) abre no primeiro acesso, antes do tour
(`VideoBoasVindas`, marca `av-boas-vindas-visto-v1` no user_metadata)

**23. Check-in e treino com energia** — [x] comemoração com confete e
sequência · [x] cronômetro e duração do treino para o professor ·
[~] duração exata depende da migração 008

---

## O QUE AINDA FALTA

1. **Gravar os áudios de bem-estar** e colar as URLs em
   `lib/utils/bem-estar.ts` (`AUDIOS`). O player já está pronto e a tela
   trata a lista vazia; é o único vazio de conteúdo que sobrou.
2. **Push e cron nunca rodaram de verdade** — `/api/cron/lembretes` e o envio
   web-push só foram lidos, não exercitados. Precisam de um device real com
   permissão de notificação concedida.
3. **Migrações a aplicar no SQL Editor** (DDL não roda pela service role; com
   `SUPABASE_ACCESS_TOKEN` no ambiente dá para rodar pela Management API, mas
   precisa de permissão liberada no Claude Code):
   - 005 trava o papel (gatilho lê `role` de `raw_app_meta_data`; professor
     novo só por `supabase/scripts/criar_professor.sql`) e 006 põe cascata nas
     chaves para `profiles`/`auth.users` — conferir se já estão no banco.
   - 007 exames: tabelas `exames` e `exames_compartilhamentos` + bucket
     privado `exames`. Sem ela a tela /exames mostra "sendo ativado".
   - 008 duração do treino: `iniciado_em`, `concluido_em`, `duracao_segundos`
     em `treino_execucoes`. Antes dela o tempo é estimado pelas séries.
   - 009 põe `notificacoes` no Realtime (comunicado chega na hora no sino).
   - 010 texto do alerta de indicador crítico sem travessão.
   - 011 e 012 já aplicadas (17/09/2026). 012 cria o papel `familiar`; o Auth
     grava o app_metadata depois do insert, então `/api/familia/cadastro`
     acerta `profiles.role` pela service role logo depois de criar a conta.
   - 016 aulas: `aulas_horarios`, `aula_inscricoes`, `aula_cancelamentos`,
     o gatilho de vaga e a função `aulas_do_periodo`.
   - 013 desafios: tabelas `desafios` e `desafio_participantes` + funções
     `ranking_desafio`, `detalhe_pontos_desafio` e `resumo_desafios`.
   - 014 desafio com meta: `tipo`, `metrica` e `objetivo` em `desafios`,
     tabela `desafio_registros` e função `progresso_desafio`.
   - 015 capa e anexo do desafio: `imagem_url`, `arquivo_url`, `arquivo_nome`
     e o bucket público `desafios` (só professor escreve).
   - 017 admin da equipe: coluna `profiles.eh_admin`, trava estendida e o
     primeiro admin (`marlos.h.santos@gmail.com`). Sem ela a aba Equipe não
     aparece para ninguém.
   - 018 central de notificações: já aplicada, com os dois segredos no
     Vault (`notificacoes_url` e `notificacoes_segredo` = `CRON_SECRET`).
   - 019 endurece permissões: escrita em treinos, exercícios, eventos,
     comunicados e avaliações só para professor; chat só em nome próprio e
     com professor numa ponta; aluno não edita medição; prazo de 2 h para
     desmarcar aula no banco; equipe nunca sem admin; funções de apoio da
     018 fora do alcance do app; todo professor lê os treinos (edita só quem
     criou); aula reaberta avisa a turma; aceite de convite de familiar por
     `aceitar_convite_familiar()`; teto de 200 no registro de km; textos dos
     avisos sem "seu professor". **Aplicar antes de entregar.**
   - 020 dobras cutâneas: colunas `protocolo`, `sexo`, `idade`, as sete
     `dobra_*`, `soma_dobras`, `densidade_corporal`, `massa_gorda` e
     `massa_magra` em `avaliacoes_fisicas`. Só acrescenta. Antes dela, a
     avaliação sem dobras salva normal e a com dobras dá erro ao gravar.
   - 021 tipo de treino: coluna `tipo` em `treinos` e em `exercicios`. Antes
     dela, treino sem tipo salva normal e o com tipo dá erro ao gravar.
   - 022 lesões: tabela `lesoes` com RLS (aluno avisa e lê as dele, professor
     lê e resolve) e o gatilho que cria o alerta. Sem ela a tela /lesoes
     mostra "sendo ativado" e a seção some da ficha.
   - 023 colesterol: tabela `colesterol_registros` com RLS (aluno registra e
     lê os dele, sem editar; professor lê). Sem ela a seção mostra "sendo
     ativado".
   - 024 videoaulas: tabela `videoaulas` com RLS (todos leem as ativas,
     professor gerencia). Sem ela as duas telas mostram "sendo ativada".
   - 011 anamnese editável: tabela `anamnese_perguntas` + `anamneses.respostas`
     (jsonb por id da pergunta). Sem ela o formulário usa `PERGUNTAS_PADRAO`
     de `lib/utils/anamnese.ts` e o editor fica só leitura. As colunas antigas
     de `anamneses` continuam sendo gravadas pelas perguntas originais
     (`coluna_legada`).
4. **Convite por e-mail** — feito em 17/09/2026: `bash scripts/aplicar_emails.sh`
   manda os modelos de `docs/emails/*.html` (marca Atitude Vital), os assuntos
   em português, a Site URL de produção e as Redirect URLs. O cadastro público
   foi desligado no Supabase (`disable_signup`) em 28/09/2026; convite, equipe
   e familiar criam conta pela API de admin e não são afetados.
   SMTP próprio ligado em 29/09/2026: domínio `envio.ctatitudevital.com.br`
   verificado no Resend (conta do peritos-academy, sa-east-1), chave só de
   envio em `RESEND_API_KEY` e Site URL em `https://ctatitudevital.com.br`.
   A mesma chave manda os e-mails da central de notificações (módulo 27) e
   precisa estar também nas variáveis da Vercel.

5. **Domínio próprio** `ctatitudevital.com.br` (Registro.br, modo avançado
   de DNS): `A` na raiz → `76.76.21.21`, `www` → `cname.vercel-dns.com`, e os
   registros do Resend em `*.envio`. Os dois nomes estão no projeto da Vercel.

**Já resolvido:** projeto na Vercel (time Pro) com as sete variáveis nos três
ambientes; "esqueci a senha" (`/esqueci-senha` → e-mail →
`/auth/confirmar` → `/redefinir-senha`). Para os links de e-mail funcionarem,
o domínio da Vercel precisa estar em Authentication → URL Configuration.

---

## DADOS DE TESTE

`node supabase/scripts/popular_dados_teste.mjs --confirmo` povoa o banco com uma academia
inteira: uma professora, oito alunos de condições diferentes e dois meses de
história. Roda quantas vezes quiser — apaga o que semeou antes e o sorteio tem
semente fixa, então o resultado é sempre o mesmo. **Não rode em produção**:
desde a 018 os eventos e comunicados semeados mandam push aos alunos reais.

Todo mundo entra com a senha `teste1234`:

| Conta | Quem é |
|---|---|
| `professora@teste.local` | Rita Salgado — dona dos treinos, e por isso dos alertas |
| `ana@teste.local` | diabética e obesa — **sumida há 9 dias** |
| `joao@teste.local` | hipertenso, cardiopata, 60+ — **pico de 168/104** |
| `marlene@teste.local` | 60+, menopausa, colesterol — presença perfeita |
| `pedro@teste.local` | performance |
| `beatriz@teste.local` | gestante |
| `sergio@teste.local` | colesterol e hipertenso — frequência irregular |
| `lucas@teste.local` | adolescente |
| `rosa@teste.local` | diabética, hipertensa, 60+ — **glicemia 211** |

Os três em negrito existem para exercitar caminho de exceção: lista de sumidos,
alerta em tempo real com o portão pré-treino barrando, e semáforo vermelho.

O semáforo e os alertas **não** são semeados — quem os cria é o gatilho do
banco ao receber os indicadores. Se a distribuição sair diferente de ~400
verde / 60 amarelo / 2 vermelho, o gatilho é que mudou.

Alerta tem dono: a policy é `auth.uid() = professor_id` e
`professor_responsavel()` acha o professor pelo treino ativo do aluno. Por isso
o seed pendura os treinos na Rita — entrando com outra conta de professor você
vê os alunos (a lista é da casa inteira) mas não os alertas.

---

## COMO PEDIR AJUDA AO CLAUDE

Seja específico sobre o módulo e o que precisa:

**Exemplos de prompts eficientes:**
- "Crie a tela /app/(aluno)/indicadores/page.tsx seguindo o padrão do projeto. O aluno deve conseguir registrar glicemia, pressão e peso. Após salvar, mostrar o semáforo com a cor correta. Se vermelho, criar alerta na tabela alertas_professor."
- "Crie o componente CardAluno em /components/professor/CardAluno.tsx. Deve mostrar foto, nome, condição clínica, se treinou hoje, humor do dia e último indicador com semáforo."
- "Adicione notificações push no módulo de medicamentos. Quando o horário do medicamento chegar e o aluno não confirmar em 15 minutos, enviar reforço."

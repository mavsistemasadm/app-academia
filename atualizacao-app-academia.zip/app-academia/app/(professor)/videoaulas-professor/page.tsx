import { redirect } from "next/navigation";

import { GerenciarVideoaulas } from "@/components/professor/GerenciarVideoaulas";
import { CabecalhoPagina } from "@/components/shared/CabecalhoPagina";
import { getPerfilAtual } from "@/lib/supabase/perfil";
import { getVideoaulas } from "@/lib/supabase/videoaulas";

export default async function VideoaulasProfessorPage() {
  const perfil = await getPerfilAtual();
  if (!perfil) redirect("/login");

  const { videoaulas, indisponivel } = await getVideoaulas({ incluirOcultas: true });

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-6 md:gap-8 md:px-6 md:py-8">
      <div className="-mx-5 -mt-7 md:m-0">
        <CabecalhoPagina
          rotulo="Biblioteca"
          titulo="Videoaulas"
          descricao="Cole o link do YouTube ou Vimeo. O aluno assiste em Videoaulas, filtrando por tipo."
        />
      </div>

      <GerenciarVideoaulas videoaulas={videoaulas} indisponivel={indisponivel} />
    </main>
  );
}

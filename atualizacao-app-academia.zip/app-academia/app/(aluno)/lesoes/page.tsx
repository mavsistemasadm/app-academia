import { redirect } from "next/navigation";

import { AvisarLesao } from "@/components/aluno/AvisarLesao";
import { CabecalhoPagina } from "@/components/shared/CabecalhoPagina";
import { getLesoesDoAluno } from "@/lib/supabase/lesoes";
import { getPerfilAtual } from "@/lib/supabase/perfil";
import { hojeISO } from "@/lib/utils/datas";

export const metadata = { title: "Lesões e dores" };

export default async function LesoesPage() {
  const perfil = await getPerfilAtual();
  if (!perfil) redirect("/login");

  const { lesoes, indisponivel } = await getLesoesDoAluno(perfil.id);
  const ativas = lesoes.filter((l) => l.status === "ativa").length;

  return (
    <div className="flex flex-col gap-7 pt-0 md:gap-9 md:px-8 md:pt-10">
      <CabecalhoPagina
        rotulo="Saúde"
        titulo="Lesões e dores"
        descricao={
          ativas > 0
            ? `${ativas} ${ativas === 1 ? "aviso em acompanhamento" : "avisos em acompanhamento"} pelo professor.`
            : "Sentiu alguma dor ou se machucou? Avise aqui, a qualquer hora."
        }
      />

      <div className="flex flex-col gap-6 px-5 md:gap-8 md:px-0">
        <AvisarLesao
          alunoId={perfil.id}
          lesoes={lesoes}
          hoje={hojeISO()}
          indisponivel={indisponivel}
        />
      </div>
    </div>
  );
}

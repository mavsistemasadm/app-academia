import { redirect } from "next/navigation";
import { AlertCircle, Clapperboard } from "lucide-react";

import { CabecalhoPagina } from "@/components/shared/CabecalhoPagina";
import { ChipTipo, FiltroTipo } from "@/components/shared/FiltroTipo";
import { VideoExercicio } from "@/components/shared/VideoExercicio";
import { getPerfilAtual } from "@/lib/supabase/perfil";
import { getVideoaulas } from "@/lib/supabase/videoaulas";
import {
  NOME_TIPO_VIDEOAULA,
  TIPOS_VIDEOAULA,
  ehTipoVideoaula,
  formatarMinutos,
} from "@/lib/utils/videoaulas";

export const metadata = { title: "Videoaulas" };

export default async function VideoaulasPage({
  searchParams,
}: {
  searchParams: Promise<{ tipo?: string }>;
}) {
  const perfil = await getPerfilAtual();
  if (!perfil) redirect("/login");

  const { tipo: tipoBruto } = await searchParams;
  const filtro = ehTipoVideoaula(tipoBruto) ? tipoBruto : null;

  const { videoaulas: todas, indisponivel } = await getVideoaulas();
  const videoaulas = filtro ? todas.filter((v) => v.tipo === filtro) : todas;

  return (
    <div className="flex flex-col gap-7 pt-0 md:gap-9 md:px-8 md:pt-10">
      <CabecalhoPagina
        rotulo="Para assistir"
        titulo="Videoaulas"
        descricao="Aulas gravadas pela equipe para você fazer em casa ou revisar o movimento."
      />

      <div className="flex flex-col gap-5 px-5 md:gap-6 md:px-0">
        {indisponivel ? (
          <div className="flex items-start gap-3.5 rounded-2xl bg-card px-5 py-4 ring-1 ring-neutral-200/90">
            <AlertCircle className="mt-0.5 size-5 shrink-0 text-neutral-400" strokeWidth={1.8} aria-hidden />
            <p className="text-sm leading-relaxed text-neutral-500">
              A biblioteca de videoaulas ainda está sendo ativada pelo centro. Volte daqui a pouco.
            </p>
          </div>
        ) : todas.length === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-2xl bg-card px-6 py-10 text-center ring-1 ring-neutral-200/90">
            <Clapperboard className="size-6 text-neutral-400" strokeWidth={1.8} aria-hidden />
            <p className="text-[15px] font-semibold text-neutral-950">Em breve, as primeiras aulas</p>
            <p className="max-w-xs text-sm leading-relaxed text-neutral-500">
              A equipe está gravando. Assim que publicar, elas aparecem aqui.
            </p>
          </div>
        ) : (
          <>
            <FiltroTipo
              caminho="/videoaulas"
              opcoes={TIPOS_VIDEOAULA}
              nomes={NOME_TIPO_VIDEOAULA}
              atual={filtro}
            />

            {videoaulas.length === 0 ? (
              <p className="rounded-2xl bg-card px-5 py-8 text-center text-[15px] text-neutral-500 ring-1 ring-neutral-200/90">
                Ainda não há aulas de {NOME_TIPO_VIDEOAULA[filtro!].toLowerCase()}.
              </p>
            ) : (
              <ul className="grid gap-3 md:gap-4 lg:grid-cols-2">
                {videoaulas.map((aula) => {
                  const duracao = formatarMinutos(aula.duracao_minutos);
                  return (
                    <li
                      key={aula.id}
                      className="flex flex-col gap-3 rounded-2xl bg-card p-5 ring-1 ring-neutral-200/90"
                    >
                      <div className="flex items-center gap-2">
                        <ChipTipo>{NOME_TIPO_VIDEOAULA[aula.tipo]}</ChipTipo>
                        {duracao && <span className="rotulo text-neutral-400">{duracao}</span>}
                      </div>
                      <h2 className="text-lg leading-snug font-semibold tracking-[-0.02em] text-neutral-950">
                        {aula.titulo}
                      </h2>
                      {aula.descricao && (
                        <p className="text-[15px] leading-relaxed text-neutral-600">{aula.descricao}</p>
                      )}
                      <div className="mt-auto pt-1">
                        <VideoExercicio
                          url={aula.url}
                          nome={aula.titulo}
                          rotulo="Assistir"
                          titulo={`Videoaula: ${aula.titulo}`}
                        />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </>
        )}
      </div>
    </div>
  );
}
